# Run Gidan asusu

## Requirements

- Node.js 22.5 or newer
- Install the app's npm dependency with `npm install`

## Start the app

1. Extract this ZIP.
2. Open a terminal in the extracted `app` folder (the folder containing `package.json`).
3. Run:

   ```sh
   npm install
   npm start
   ```

4. Open `http://localhost:3000` for the customer app. The local sandbox database is created automatically the first time the server starts.

## Access the admin dashboard

1. Create a regular account from the customer app.
2. Stop the server with `Ctrl+C`.
3. In the same terminal, promote that account using the email you registered:

   ```sh
   npm run make-admin -- you@example.com
   ```

4. Start the server again with `npm start`.
5. Open `http://localhost:3000/admin.html` and sign in with the promoted account's email and password.

Promotion is local to this app's database. The command revokes existing sessions for that account, so sign in again after promotion. Do not use real banking credentials, real customer documents, or real financial data in the sandbox.

## Useful commands

```sh
npm test       # Run the API and customer-screen smoke tests
npm run seed   # Add sandbox marketplace demo listings
npm run jobs   # Run savings interest jobs manually
```

## Install the app and enable push

The app can be installed from Chrome on Android or Safari on iOS/iPadOS (Share → Add to Home Screen). Production push requires HTTPS; `localhost` is allowed for local development. On iOS/iPadOS, install it before requesting notification permission.

Generate a VAPID key pair with `npx web-push generate-vapid-keys`, then set `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, and `VAPID_SUBJECT` in the deployment's environment/secrets. Do not commit the private key or put it in the frontend. Users can then opt in from **More → Notifications**. If keys are missing or invalid, push stays unavailable and the rest of the app continues to work.
