// Identity-check provider adapter: BVN and NIN lookups. Two modes, chosen by KYC_PROVIDER:
//   mock  (default) a sandbox that "finds" the customer's own name, with special numbers for testing failures.
//   http  a configurable REST client: point it at your provider (Dojah, Smile ID, Prembly, etc.) using environment
//         variables only. BVN and NIN share the credentials (KYC_AUTH_VALUE, KYC_AUTH_HEADER, KYC_EXTRA_HEADERS, KYC_TIMEOUT_MS);
//         each has its own address and field map:  BVN = KYC_URL / KYC_MAP / KYC_BODY / KYC_METHOD,  NIN = KYC_NIN_URL / KYC_NIN_MAP / KYC_NIN_BODY / KYC_NIN_METHOD.
//         NIN is offered to customers only when KYC_NIN_URL and KYC_NIN_MAP are set. See docs/GOING_LIVE.md.
// Nothing here logs or stores the number being checked. Settings are read on every call so they can be changed without a restart in tests.
const TIMEOUT=()=>+(process.env.KYC_TIMEOUT_MS||8000);
const getPath=(o,p)=>String(p||'').split('.').reduce((a,k)=>a==null?a:a[k],o);
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z ]/g,' ').split(/\s+/).filter(Boolean);
const err=(m)=>Object.assign(new Error(m),{provider:true});
const parse=(s)=>{try{return JSON.parse(s||'{}')}catch{return null}};

async function httpLookup(kind,id){
  const P=kind=='nin'?'KYC_NIN_':'KYC_',url=process.env[P+'URL'],key=process.env.KYC_AUTH_VALUE,map=parse(process.env[P+'MAP']);
  if(!map)throw err(P+'MAP is not valid JSON');
  if(!url||!key||!map.first||!map.last)throw err(`KYC provider is not configured for ${kind.toUpperCase()} (${P}URL, KYC_AUTH_VALUE, ${P}MAP)`);
  const slot='{'+kind+'}',method=(process.env[P+'METHOD']||process.env.KYC_METHOD||'GET').toUpperCase(),headers={'Content-Type':'application/json',[process.env.KYC_AUTH_HEADER||'Authorization']:key,...parse(process.env.KYC_EXTRA_HEADERS)};
  const body=method=='GET'?undefined:(process.env[P+'BODY']||`{"${kind}":"${slot}"}`).replace(slot,id);   // id is 11 digits (validated by the route)
  let last;
  for(let i=0;i<2;i++){                                                                              // one automatic retry for network errors, timeouts and 5xx / 429
    const ctl=new AbortController(),timer=setTimeout(()=>ctl.abort(),TIMEOUT());
    try{const r=await fetch(url.replace(slot,encodeURIComponent(id)),{method,headers,body,signal:ctl.signal});
      if(r.status==404||r.status==400||r.status==422)return null;                                    // unknown or invalid number
      if(r.status==401||r.status==403)throw err('Provider rejected our credentials (HTTP '+r.status+')');// our configuration problem, not the customer's
      if(r.status>=500||r.status==429){last=err('Provider error HTTP '+r.status);continue}
      if(!r.ok)throw err('Unexpected provider response HTTP '+r.status);
      const j=await r.json();if(map.found&&!getPath(j,map.found))return null;
      return {first:getPath(j,map.first),last:getPath(j,map.last),middle:getPath(j,map.middle),phone:getPath(j,map.phone)}}
    catch(e){if(e.provider&&!/Provider error/.test(e.message))throw e;last=e.provider?e:err('Could not reach the provider: '+(e.name=='AbortError'?'timed out':e.message))}
    finally{clearTimeout(timer)}
    await new Promise(r=>setTimeout(r,200))}
  throw last}

// Sandbox: numbers ending 0000 = not found, 1111 = belongs to someone else, 9999 = provider outage. Anything else matches the customer.
async function mockLookup(id,hint){if(id.endsWith('0000'))return null;if(id.endsWith('9999'))throw err('mock provider outage');
  if(id.endsWith('1111'))return {first:'Someone',last:'Else',phone:'08000000000'};
  const p=norm(hint.name);return {first:p[0],last:p[p.length-1],phone:hint.phone}}

// The name on the record must contain the first and last name on the account (any order, any case, accents ignored).
const nameMatches=(account,rec)=>{const a=norm(account),have=new Set(norm([rec.first,rec.middle,rec.last].join(' ')));return a.length>=2&&have.has(a[0])&&have.has(a[a.length-1])};
const digits=s=>String(s||'').replace(/\D/g,'').slice(-10);
const isMock=()=>process.env.KYC_PROVIDER!=='http';
// Which checks customers may use right now. NIN appears only when its address and field map are set (or in the sandbox).
const methods=()=>{const m=['bvn'],map=parse(process.env.KYC_NIN_MAP);if(isMock()||(process.env.KYC_NIN_URL&&map&&map.first&&map.last))m.push('nin');return m};
async function verifyId({kind='bvn',id,name,phone}){
  const rec=isMock()?await mockLookup(id,{name,phone}):await httpLookup(kind,id);
  if(!rec)return {status:'not_found'};
  if(!nameMatches(name,rec))return {status:'mismatch'};
  return {status:'verified',phoneMatch:rec.phone?digits(rec.phone)===digits(phone):null}}
const verifyBvn=({bvn,name,phone})=>verifyId({kind:'bvn',id:bvn,name,phone}),verifyNin=({nin,name,phone})=>verifyId({kind:'nin',id:nin,name,phone});
module.exports={verifyId,verifyBvn,verifyNin,nameMatches,methods,isMock,providerName:()=>isMock()?'mock':'http'};
