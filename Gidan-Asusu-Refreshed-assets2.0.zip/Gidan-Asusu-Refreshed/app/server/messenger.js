// Delivers messages. "mock" prints to the server console and remembers them in `sent` (sandbox and tests only).
// For live use implement sendResetCode and sendSms with an SMS provider (e.g. Termii, Twilio) and/or email (SMTP),
// and sendPush with Firebase Cloud Messaging once the app is wrapped as a native app. Then set MESSENGER.
const sent=[];
const mock={sent,
  async sendResetCode({phone,email,code}){console.log(`[sandbox] reset code for ${phone} / ${email}: ${code}`)},
  async sendSms({phone,text}){if(mock.failNext>0){mock.failNext--;throw new Error('simulated SMS provider outage')}sent.push({phone,text});if(sent.length>200)sent.shift();console.log(`[sandbox] SMS to ${phone}: ${text}`)},
  async sendPush({userId,title,body}){}};
const live=async()=>{throw new Error('Messaging provider not configured. Implement server/messenger.js')};
module.exports=process.env.MESSENGER&&process.env.MESSENGER!=='mock'?{sendResetCode:live,sendSms:live,sendPush:live,live:true}:mock;
