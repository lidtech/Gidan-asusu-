// Savings interest: accrued DAILY on every goal, PAID OUT monthly into the goal.
// Daily accrual means a last-day deposit can't earn a full month's interest. All steps are idempotent
// (job_runs has one row per day/month), so running late, twice, or after downtime is safe.
// Interest is kept in micro-kobo (1e-6 kobo) so no rounding errors build up.
const {tx,one,all,run}=require('./db'),{ratePct}=require('./interest'),{notify}=require('./notify');
const lagos=ms=>new Date(ms+36e5).toISOString();                 // Lagos is UTC+1 all year
const day=ms=>lagos(ms).slice(0,10),nextDay=d=>new Date(Date.parse(d+'T00:00:00Z')+864e5).toISOString().slice(0,10);
const once=(name,period,fn)=>tx(()=>{try{run('INSERT INTO job_runs(name,period) VALUES(?,?)',name,period)}catch{return 0}return fn()});
const accrueDay=d=>once('accrue',d,()=>{let n=0;
  for(const u of all('SELECT user_id,SUM(saved) t FROM goals GROUP BY user_id')){const r=ratePct(u.t);
    for(const g of all('SELECT id,saved FROM goals WHERE user_id=? AND saved>0',u.user_id)){run('UPDATE goals SET accrued=accrued+? WHERE id=?',Math.round(g.saved*r*1e4/365),g.id);n++}}return n});
const payoutMonth=m=>once('payout',m,()=>{let n=0;
  for(const g of all('SELECT * FROM goals WHERE accrued>=1000000')){const k=Math.floor(g.accrued/1e6),rate=ratePct(one('SELECT SUM(saved) t FROM goals WHERE user_id=?',g.user_id).t);
    run('UPDATE goals SET saved=saved+?,accrued=accrued-? WHERE id=?',k,k*1e6,g.id);
    run('INSERT INTO interest_log(user_id,goal_id,period,amount,rate,created_at) VALUES(?,?,?,?,?,?)',g.user_id,g.id,m,k,rate,Date.now());notify(g.user_id,'info','Savings interest paid','₦'+(k/100).toLocaleString()+' was added to '+g.name+'.');n++}return n});
// Catches up on every missed day, paying out each month as the calendar crosses into the next.
function runDue(now=Date.now()){const today=day(now),last=one("SELECT MAX(period) p FROM job_runs WHERE name='accrue'").p,out={accrued:0,paid:0};
  if(!last){out.accrued+=accrueDay(today);return out}
  let d=last;for(let i=0;i<62&&d<today;i++){const nx=nextDay(d);if(nx.slice(0,7)!==d.slice(0,7))out.paid+=payoutMonth(d.slice(0,7));out.accrued+=accrueDay(nx);d=nx}
  return out}
module.exports={runDue,accrueDay,payoutMonth};
