// Rules-based loan decisioning from real account data. Replace/extend with credit bureau
// (CRC / FirstCentral) data and a regulator-approved policy before lending real money.
const {one,all}=require('./db');
const DAY=864e5,MIN_AGE=+(process.env.LOAN_MIN_AGE_DAYS||0),RATE=0.05; // 5% flat per month
const total=(p,m)=>Math.round(p*(1+RATE*m));
function assess(uid){
  const u=one('SELECT * FROM users WHERE id=?',uid),acc=one('SELECT * FROM accounts WHERE user_id=?',uid),now=Date.now();
  const reasons=[],active=one("SELECT * FROM loans WHERE user_id=? AND status='active'",uid);
  const ins=all("SELECT amount,created_at FROM ledger WHERE account_id=? AND amount>0 AND kind IN('fund','transfer_in') AND created_at>=?",acc.id,now-90*DAY);
  const months=new Set(ins.map(r=>Math.floor((now-r.created_at)/(30*DAY)))).size;
  const avg=ins.reduce((a,r)=>a+r.amount,0)/3/100;                                  // avg monthly inflow, naira
  const saved=one('SELECT COALESCE(SUM(saved),0) s FROM goals WHERE user_id=?',uid).s/100;
  const age=(now-u.created_at)/DAY;
  const score=Math.min(30,months*10)+Math.min(30,Math.floor(avg/10000))+Math.min(30,Math.floor(saved/10000))+Math.min(10,Math.floor(age/9));
  let decision=score>=50?'approve':score>=40?'review':'decline';
  if(u.kyc_tier<2){decision='decline';reasons.push('Verify your BVN to unlock loans')}
  if(active){decision='decline';reasons.push('Repay your current loan first')}
  if(age<MIN_AGE){decision='decline';reasons.push(`Account must be ${MIN_AGE} days old`)}
  if(score<40)reasons.push('Build a history: receive regular deposits and save more');
  if(decision=='review')reasons.push('Needs a manual review by our credit team');
  const cap=score>=70?500000:score>=50?150000:0;
  const limit=decision=='approve'?Math.floor(Math.min(cap,Math.max(avg*1.5,saved*2))/1000)*1000:0;
  return {score,limit,decision,reasons,review:!!one("SELECT 1 x FROM loans WHERE user_id=? AND status='review'",uid),active:active&&{id:active.id,remaining:(active.total-active.paid)/100,total:active.total/100}};
}
module.exports={assess,total,RATE};
