// Savings reward tiers, by the customer's TOTAL savings (kobo): 8% p.a., 10% from ₦100,000, 12% from ₦500,000.
const ratePct=totalKobo=>totalKobo>=5e7?12:totalKobo>=1e7?10:8;
module.exports={ratePct};
