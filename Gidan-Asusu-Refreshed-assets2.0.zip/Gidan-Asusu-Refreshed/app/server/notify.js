// Alerts. Every event is saved to the in-app inbox; important ones are ALSO texted (unless the customer turned SMS off).
// Security alerts are always texted. Texts never contain balances, PINs or codes beyond the one-time reset code.
const {one,all,run}=require('./db'),msg=require('./messenger');
const webpush=require('web-push');
const SMS_KINDS=new Set(['loan','kyc','dispute','security','money']);          // 'info' and 'order' stay in the app
const PUSH_TITLES={en:{money:'Money update',loan:'Loan update',kyc:'Identity update',security:'Security alert',order:'Order update',dispute:'Dispute update',info:'Account update'},
  ar:{money:'تحديث مالي',loan:'تحديث القرض',kyc:'تحديث الهوية',security:'تنبيه أمني',order:'تحديث الطلب',dispute:'تحديث النزاع',info:'تحديث الحساب'},
  // ha/yo/ig/pcm are drafts awaiting native-speaker review (docs/TRANSLATION_REVIEW.md).
  ha:{money:'Sabuntawa kan kuɗi',loan:'Sabuntawa kan rance',kyc:'Sabuntawa kan shaida',security:'Gargaɗin tsaro',order:'Sabuntawa kan oda',dispute:'Sabuntawa kan jayayya',info:'Sabuntawa kan asusu'},
  yo:{money:'Ìròyìn owó',loan:'Ìròyìn awin',kyc:'Ìròyìn ìdánimọ̀',security:'Ìkìlọ̀ ààbò',order:'Ìròyìn àṣẹ',dispute:'Ìròyìn àríyànjiyàn',info:'Ìròyìn àkáǹtì'},
  ig:{money:'Ozi gbasara ego',loan:'Ozi gbasara mgbazinye',kyc:'Ozi gbasara njirimara',security:'Ịdọ aka ná ntị nchekwa',order:'Ozi gbasara oda',dispute:'Ozi gbasara esemokwu',info:'Ozi gbasara akaụntụ'},
  pcm:{money:'Money update',loan:'Loan update',kyc:'Identity update',security:'Security alert',order:'Order update',dispute:'Dispute update',info:'Account update'}};
const PUSH_BODY={en:'Open the app to view details.',ar:'افتح التطبيق لعرض التفاصيل.',ha:'Buɗe manhajar don ganin cikakken bayani.',yo:'Ṣí ìṣàfilọ́lẹ̀ náà láti wo àlàyé.',ig:'Mepee ngwa ka ịhụ nkọwa.',pcm:'Open di app to see details.'};
function pushConfig(){
  const publicKey=process.env.VAPID_PUBLIC_KEY||'',privateKey=process.env.VAPID_PRIVATE_KEY||'';
  if(!publicKey||!privateKey)return {enabled:false,publicKey:null};
  try{webpush.setVapidDetails(process.env.VAPID_SUBJECT||'mailto:support@example.com',publicKey,privateKey);return {enabled:true,publicKey}}
  catch{return {enabled:false,publicKey:null}}
}
async function sendPush(userId,kind){
  const cfg=pushConfig();if(!cfg.enabled)return;
  const subs=all('SELECT id,endpoint,p256dh,auth,locale FROM push_subscriptions WHERE user_id=?',userId);
  for(const s of subs){
    try{await webpush.sendNotification({endpoint:s.endpoint,keys:{p256dh:s.p256dh,auth:s.auth}},JSON.stringify({
      title:`Gidan asusu · ${(PUSH_TITLES[s.locale]||PUSH_TITLES.en)[kind]||'Account update'}`,
      body:PUSH_BODY[s.locale]||PUSH_BODY.en,
      url:'/',
      tag:`gidan-${kind||'alert'}`
    }),{TTL:3600,urgency:'normal'})}
    catch(e){if(e.statusCode===404||e.statusCode===410)run('DELETE FROM push_subscriptions WHERE id=?',s.id);
      else console.warn('Push delivery failed (HTTP '+(e.statusCode||'network error')+').')}
  }
}
function notify(userId,kind,title,body){const u=one('SELECT notify_sms FROM users WHERE id=?',userId);if(!u)return;
  const sms=SMS_KINDS.has(kind)&&(u.notify_sms||kind=='security');
  run('INSERT INTO notifications(user_id,kind,title,body,sms_state,created_at) VALUES(?,?,?,?,?,?)',userId,kind,title,body,sms?'pending':'none',Date.now());
  setImmediate(()=>sendPush(userId,kind).catch(()=>{}));
  if(sms)setImmediate(()=>flushSms().catch(()=>{}))}
// Texts go out AFTER the database work has finished, so an action that was rolled back never sends a text.
// If the SMS provider fails, the text is retried: 1 min, 5 min, 30 min, then 2 h later (5 tries in all), and then marked 'failed'
// (the admin overview counts these). Texts older than a day are dropped as stale. A text stuck 'sending' after a crash is retried too,
// so in rare cases a customer may get the same text twice (better than never getting it).
const BACKOFF=[6e4,3e5,18e5,72e5],MAX_TRIES=BACKOFF.length+1,MAX_AGE=864e5;
async function flushSms(now=Date.now()){
  run("UPDATE notifications SET sms_state='pending' WHERE sms_state='sending' AND sms_at<?",now-3e5);
  run("UPDATE notifications SET sms_state='expired' WHERE sms_state='pending' AND created_at<?",now-MAX_AGE);
  for(const n of all("SELECT n.id,n.title,n.body,n.sms_attempts a,u.phone FROM notifications n JOIN users u ON u.id=n.user_id WHERE n.sms_state='pending' AND (n.sms_next IS NULL OR n.sms_next<=?) ORDER BY n.id LIMIT 50",now)){
    if(run("UPDATE notifications SET sms_state='sending',sms_at=? WHERE id=? AND sms_state='pending'",now,n.id).changes!==1)continue;
    try{await msg.sendSms({phone:n.phone,text:`Gidan asusu: ${n.title}. ${n.body}`.slice(0,300)});run("UPDATE notifications SET sms_state='sent',sms_at=? WHERE id=?",now,n.id)}
    catch(e){const a=n.a+1;console.error(`SMS attempt ${a}/${MAX_TRIES} failed:`,e.message);
      if(a>=MAX_TRIES)run("UPDATE notifications SET sms_state='failed',sms_attempts=?,sms_at=? WHERE id=?",a,now,n.id);
      else run("UPDATE notifications SET sms_state='pending',sms_attempts=?,sms_next=?,sms_at=? WHERE id=?",a,now+BACKOFF[a-1],now,n.id)}}}
module.exports={notify,flushSms,pushConfig,sendPush};
