// Sandbox only: adds a demo seller with produce so the marketplace is not empty. Usage: npm run seed
const {run,one}=require('./db'),sec=require('./security'),crypto=require('crypto');
let u=one("SELECT id FROM users WHERE email='demo.farmer@example.com'");
if(!u){const id=Number(run('INSERT INTO users(name,email,phone,pw,pin,created_at) VALUES(?,?,?,?,?,?)','Musa Farms','demo.farmer@example.com','08000000001',sec.hash(crypto.randomBytes(12).toString('hex')),sec.hash(crypto.randomBytes(4).toString('hex')),Date.now()).lastInsertRowid);run('INSERT INTO accounts(user_id,number) VALUES(?,?)',id,'9000000001');u={id}}
for(const [n,i,c,p,un,q,l] of [['White Maize','🌾','Grains',48000,'100kg bag',40,'Kaduna'],['Local Rice (paddy)','🌾','Grains',62000,'50kg bag',25,'Kebbi'],['Dry Pepper','🍅','Vegetables',35000,'25kg bag',18,'Kano'],['Tomatoes','🍅','Vegetables',18000,'basket',60,'Zaria'],['Healthy Goat','🐐','Livestock',85000,'each',12,'Sokoto']])
  if(!one('SELECT 1 x FROM listings WHERE seller_id=? AND name=?',u.id,n))run('INSERT INTO listings(seller_id,name,icon,category,price,unit,qty,location,created_at) VALUES(?,?,?,?,?,?,?,?,?)',u.id,n,i,c,p*100,un,q,l,Date.now());
console.log('Demo listings added (seller: Musa Farms)');
