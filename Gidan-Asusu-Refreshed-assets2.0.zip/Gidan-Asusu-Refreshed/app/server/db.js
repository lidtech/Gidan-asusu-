// SQLite (built into Node 22.5+, no npm packages). Money is stored as integer kobo.
const {DatabaseSync}=require('node:sqlite');
const db=new DatabaseSync(process.env.DB_FILE||'gidan.db');
db.exec(`PRAGMA journal_mode=WAL;PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT,email TEXT UNIQUE,phone TEXT UNIQUE,pw TEXT,pin TEXT,kyc_tier INTEGER DEFAULT 1,failed INTEGER DEFAULT 0,pin_failed INTEGER DEFAULT 0,locked_until INTEGER DEFAULT 0,created_at INTEGER,token_ver INTEGER DEFAULT 0,role TEXT DEFAULT 'user',kyc_status TEXT DEFAULT 'none',harvest_pct INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY,user_id INTEGER,number TEXT UNIQUE,balance INTEGER DEFAULT 0 CHECK(balance>=0));
CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY,account_id INTEGER,amount INTEGER,kind TEXT,label TEXT,ref TEXT,created_at INTEGER);
CREATE UNIQUE INDEX IF NOT EXISTS ledger_ref ON ledger(account_id,ref,kind);
CREATE TABLE IF NOT EXISTS idem(key TEXT PRIMARY KEY,user_id INTEGER,response TEXT);
CREATE TABLE IF NOT EXISTS goals(id INTEGER PRIMARY KEY,user_id INTEGER,name TEXT,icon TEXT,target INTEGER,saved INTEGER DEFAULT 0,accrued INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS reset_codes(user_id INTEGER PRIMARY KEY,code TEXT,expires INTEGER,attempts INTEGER DEFAULT 0,window_start INTEGER,sent INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS interest_log(id INTEGER PRIMARY KEY,user_id INTEGER,goal_id INTEGER,period TEXT,amount INTEGER,rate INTEGER,created_at INTEGER,UNIQUE(goal_id,period));
CREATE TABLE IF NOT EXISTS job_runs(name TEXT,period TEXT,PRIMARY KEY(name,period));
CREATE TABLE IF NOT EXISTS kyc_docs(id INTEGER PRIMARY KEY,user_id INTEGER,type TEXT,file TEXT,mime TEXT,size INTEGER,status TEXT,note TEXT,created_at INTEGER);
CREATE TABLE IF NOT EXISTS listings(id INTEGER PRIMARY KEY,seller_id INTEGER,name TEXT,icon TEXT,category TEXT,price INTEGER,unit TEXT,qty INTEGER,location TEXT,status TEXT DEFAULT 'active',created_at INTEGER);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,ref TEXT UNIQUE,listing_id INTEGER,buyer_id INTEGER,seller_id INTEGER,item TEXT,qty INTEGER,amount INTEGER,status TEXT,dispute_reason TEXT,note TEXT,created_at INTEGER,shipped_at INTEGER,completed_at INTEGER);
CREATE TABLE IF NOT EXISTS admin_log(id INTEGER PRIMARY KEY,admin_id INTEGER,action TEXT,target TEXT,detail TEXT,created_at INTEGER);
CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY,user_id INTEGER,kind TEXT,title TEXT,body TEXT,sms_state TEXT DEFAULT 'none',read_at INTEGER,created_at INTEGER);
CREATE INDEX IF NOT EXISTS notif_user ON notifications(user_id,id);
CREATE TABLE IF NOT EXISTS push_subscriptions(id INTEGER PRIMARY KEY,user_id INTEGER NOT NULL,endpoint TEXT NOT NULL UNIQUE,p256dh TEXT NOT NULL,auth TEXT NOT NULL,locale TEXT NOT NULL DEFAULT 'en',created_at INTEGER NOT NULL);
CREATE INDEX IF NOT EXISTS push_user ON push_subscriptions(user_id);
CREATE TABLE IF NOT EXISTS kyc_checks(id INTEGER PRIMARY KEY,user_id INTEGER,bvn_hash TEXT,bvn_last4 TEXT,result TEXT,detail TEXT,provider TEXT,created_at INTEGER);
CREATE INDEX IF NOT EXISTS kyc_checks_hash ON kyc_checks(bvn_hash);
CREATE TABLE IF NOT EXISTS loans(id INTEGER PRIMARY KEY,user_id INTEGER,principal INTEGER,total INTEGER,paid INTEGER DEFAULT 0,months INTEGER,status TEXT,score INTEGER,reasons TEXT,created_at INTEGER);`);
// Upgrades for databases created by an earlier version.
for(const s of ['ALTER TABLE users ADD COLUMN role TEXT DEFAULT \'user\'','ALTER TABLE users ADD COLUMN kyc_status TEXT DEFAULT \'none\'','ALTER TABLE users ADD COLUMN harvest_pct INTEGER DEFAULT 0','ALTER TABLE loans ADD COLUMN decided_by INTEGER','ALTER TABLE loans ADD COLUMN decided_at INTEGER','ALTER TABLE loans ADD COLUMN note TEXT','ALTER TABLE users ADD COLUMN token_ver INTEGER DEFAULT 0','ALTER TABLE goals ADD COLUMN accrued INTEGER DEFAULT 0','ALTER TABLE users ADD COLUMN notify_sms INTEGER DEFAULT 1','ALTER TABLE notifications ADD COLUMN sms_attempts INTEGER DEFAULT 0','ALTER TABLE notifications ADD COLUMN sms_next INTEGER','ALTER TABLE notifications ADD COLUMN sms_at INTEGER',"ALTER TABLE kyc_checks ADD COLUMN kind TEXT DEFAULT 'bvn'","ALTER TABLE push_subscriptions ADD COLUMN locale TEXT NOT NULL DEFAULT 'en'"]){try{db.exec(s)}catch{}}
try{db.exec("CREATE UNIQUE INDEX IF NOT EXISTS kyc_one_verified_bvn ON kyc_checks(bvn_hash) WHERE result='verified'")}catch{}
// All-or-nothing block: any thrown error rolls back every balance change inside it.
const tx=fn=>{db.exec('BEGIN IMMEDIATE');try{const r=fn();db.exec('COMMIT');return r}catch(e){db.exec('ROLLBACK');throw e}};
const one=(s,...a)=>db.prepare(s).get(...a),all=(s,...a)=>db.prepare(s).all(...a),run=(s,...a)=>db.prepare(s).run(...a);
// Moves money on one account and writes the ledger row. A negative balance is blocked by the table's CHECK.
const post=(acc,amt,kind,label,ref)=>{run('UPDATE accounts SET balance=balance+? WHERE id=?',amt,acc);run('INSERT INTO ledger(account_id,amount,kind,label,ref,created_at) VALUES(?,?,?,?,?,?)',acc,amt,kind,label,ref,Date.now())};
// System accounts: ESCROW holds marketplace payments until delivery; PLATFORM collects marketplace fees.
run("INSERT OR IGNORE INTO accounts(user_id,number,balance) VALUES(0,'ESCROW',0)");run("INSERT OR IGNORE INTO accounts(user_id,number,balance) VALUES(-1,'PLATFORM',0)");
module.exports={db,tx,one,all,run,post};
