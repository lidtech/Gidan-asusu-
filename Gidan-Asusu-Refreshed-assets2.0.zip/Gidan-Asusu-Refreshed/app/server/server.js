// Gidan asusu API + static file server. Run: node server/server.js
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {tx,one,all,run,post}=require('./db'),sec=require('./security'),prov=require('./providers'),L=require('./loans'),msg=require('./messenger'),{ratePct}=require('./interest'),jobs=require('./jobs'),mk=require('./market'),{notify,flushSms,pushConfig}=require('./notify'),kp=require('./kyc-provider');
const PROD=process.env.NODE_ENV==='production',PUB=path.join(__dirname,'..','public');
class E extends Error{constructor(s,m){super(m);this.s=s}}
const R=[],route=(m,p,fn,auth=true,max=1e5)=>R.push({m,re:new RegExp('^'+p.replace(/:(\w+)/g,'(?<$1>[^/]+)')+'$'),fn,auth,max});
const kobo=v=>{const n=Math.round(Number(v)*100);if(!Number.isFinite(n)||n<=0||n>1e11)throw new E(400,'Invalid amount');return n};
const LIM={1:[50000,300000],2:[1000000,2000000],3:[5000000,10000000]}; // [per-transaction, per-day] naira by KYC tier
const normPhone=p=>{p=String(p||'').replace(/[\s-]/g,'');if(p.startsWith('+234'))p='0'+p.slice(4);return /^0\d{10}$/.test(p)?p:null};

const strongPw=p=>p.length>=8&&/[a-z]/i.test(p)&&/\d/.test(p);
const newNo=()=>{for(;;){const n=String(crypto.randomInt(1e9,1e10));if(!one('SELECT 1 x FROM accounts WHERE number=?',n))return n}};
const ref=()=>'GIDAN'+crypto.randomBytes(5).toString('hex').toUpperCase();
const acctOf=u=>one('SELECT * FROM accounts WHERE user_id=?',u.id);
const pub=u=>({name:u.name,email:u.email,phone:u.phone,tier:u.kyc_tier,kycStatus:u.kyc_status,role:u.role,harvestPct:u.harvest_pct,smsAlerts:!!u.notify_sms});
const guardMoney=(u,acc,a)=>{const [pt,pd]=LIM[u.kyc_tier]||LIM[1];if(a>pt*100)throw new E(403,`Limit per transaction is ₦${pt.toLocaleString()} (verify BVN to raise it)`);
  const day=new Date().setHours(0,0,0,0),used=-one("SELECT COALESCE(SUM(amount),0) s FROM ledger WHERE account_id=? AND amount<0 AND kind IN('transfer_out','bank_out','bill','market_pay') AND created_at>=?",acc.id,day).s;
  if(used+a>pd*100)throw new E(403,`Daily limit of ₦${pd.toLocaleString()} reached`)};
const verifyPin=(u,pin)=>{const f=one('SELECT * FROM users WHERE id=?',u.id);if(f.pin_failed>=3)throw new E(423,'PIN locked. Contact support.');
  if(!/^\d{4}$/.test(String(pin))||!sec.check(String(pin),f.pin)){run('UPDATE users SET pin_failed=pin_failed+1 WHERE id=?',u.id);if(f.pin_failed+1==3)notify(u.id,'security','PIN locked','Your transaction PIN was locked after 3 wrong tries. Contact support if this was not you.');throw new E(401,'Incorrect PIN')}run('UPDATE users SET pin_failed=0 WHERE id=?',u.id)};
// Idempotency: the same Idempotency-Key never moves money twice (safe retries on bad networks).
const idem=async(c,fn)=>{const k=c.req.headers['idempotency-key'];if(!k||k.length<8)throw new E(400,'Idempotency-Key header required');const key=c.user.id+':'+k;
  try{run('INSERT INTO idem(key,user_id) VALUES(?,?)',key,c.user.id)}catch{const p=one('SELECT response FROM idem WHERE key=?',key);if(p&&p.response)return JSON.parse(p.response);throw new E(409,'Request already in progress')}
  try{const r=await fn();run('UPDATE idem SET response=? WHERE key=?',JSON.stringify(r),key);return r}catch(e){run('DELETE FROM idem WHERE key=?',key);throw e}};
const money=fn=>{try{return fn()}catch(e){if(/CHECK constraint/.test(e.message))throw new E(402,'Insufficient funds');throw e}};

// ---------- auth ----------
route('POST','/api/auth/signup',({body:b})=>{
  const name=clean(b.name).slice(0,60),email=String(b.email||'').trim().toLowerCase(),phone=normPhone(b.phone),pw=String(b.password||''),pin=String(b.pin||'');
  if(name.length<3||/[<>&"]/.test(name))throw new E(400,'Enter your full name (letters only)');if(!/^\S+@\S+\.\S+$/.test(email))throw new E(400,'Enter a valid email');
  if(!phone)throw new E(400,'Enter a valid Nigerian phone number');if(pw.length<8||!/[a-z]/i.test(pw)||!/\d/.test(pw))throw new E(400,'Password needs 8+ characters with letters and numbers');
  if(!/^\d{4}$/.test(pin))throw new E(400,'Choose a 4-digit transaction PIN');
  try{const id=tx(()=>{const id=Number(run('INSERT INTO users(name,email,phone,pw,pin,created_at) VALUES(?,?,?,?,?,?)',name,email,phone,sec.hash(pw),sec.hash(pin),Date.now()).lastInsertRowid);run('INSERT INTO accounts(user_id,number) VALUES(?,?)',id,newNo());return id});
    const u=one('SELECT * FROM users WHERE id=?',id);return {token:sec.sign({uid:id,ver:u.token_ver}),user:pub(u)}}
  catch(e){if(/UNIQUE/.test(e.message))throw new E(409,'Email or phone is already registered');throw e}},false);
route('POST','/api/auth/login',({body:b})=>{
  const id=String(b.id||'').trim().toLowerCase(),u=one('SELECT * FROM users WHERE email=? OR phone=?',id,normPhone(id)||'-');
  if(!u){sec.check('x',sec.DUMMY);throw new E(401,'Invalid email/phone or password')}
  if(u.locked_until>Date.now())throw new E(423,'Too many attempts. Try again in 15 minutes.');
  if(!sec.check(String(b.password||''),u.pw)){const f=u.failed+1;run('UPDATE users SET failed=?,locked_until=? WHERE id=?',f>=5?0:f,f>=5?Date.now()+9e5:0,u.id);if(f>=5)notify(u.id,'security','Account locked','Too many wrong passwords. Sign-in is paused for 15 minutes. Contact support if this was not you.');throw new E(401,'Invalid email/phone or password')}
  run('UPDATE users SET failed=0 WHERE id=?',u.id);return {token:sec.sign({uid:u.id,ver:u.token_ver}),user:pub(u)}},false);
// Password reset: 6-digit code (10 min, 5 tries, 3 sends/hour). The reply never reveals whether an account exists.
// A successful reset also signs the user out everywhere (token_ver) and clears any login lockout.
route('POST','/api/auth/forgot',async({body:b})=>{const id=String(b.id||'').trim().toLowerCase(),u=one('SELECT * FROM users WHERE email=? OR phone=?',id,normPhone(id)||'-'),out={status:'sent',message:'If that account exists, a 6-digit code has been sent.'};
  if(!u)return out;const now=Date.now(),r=one('SELECT * FROM reset_codes WHERE user_id=?',u.id);let sent=1,ws=now;
  if(r&&now-r.window_start<36e5){if(r.sent>=3)return out;sent=r.sent+1;ws=r.window_start}
  const code=String(crypto.randomInt(0,1e6)).padStart(6,'0');
  run('INSERT OR REPLACE INTO reset_codes(user_id,code,expires,attempts,window_start,sent) VALUES(?,?,?,?,?,?)',u.id,sec.hash(code),now+6e5,0,ws,sent);
  await msg.sendResetCode({phone:u.phone,email:u.email,code}).catch(e=>console.error('messenger:',e.message));
  if(!PROD)out.devCode=code;return out},false);
route('POST','/api/auth/reset',({body:b})=>{const id=String(b.id||'').trim().toLowerCase(),u=one('SELECT * FROM users WHERE email=? OR phone=?',id,normPhone(id)||'-'),pw=String(b.password||'');
  if(!strongPw(pw))throw new E(400,'Password needs 8+ characters with letters and numbers');
  const r=u&&one('SELECT * FROM reset_codes WHERE user_id=?',u.id);if(!r||r.expires<Date.now()||r.attempts>=5)throw new E(400,'Invalid or expired code');
  if(!sec.check(String(b.code||''),r.code)){run('UPDATE reset_codes SET attempts=attempts+1 WHERE user_id=?',u.id);throw new E(400,'Invalid or expired code')}
  tx(()=>{run('UPDATE users SET pw=?,failed=0,locked_until=0,token_ver=token_ver+1 WHERE id=?',sec.hash(pw),u.id);run('DELETE FROM reset_codes WHERE user_id=?',u.id)});notify(u.id,'security','Password changed','Your password was just changed. If this was not you, contact support now.');return {ok:true}},false);
route('GET','/api/me',({user:u})=>{const a=acctOf(u);return {user:pub(u),methods:kp.methods(),account:{number:a.number,balance:a.balance/100}}});
// BVN check through the identity provider (server/kyc-provider.js). The full BVN is never stored: only a keyed hash (so one BVN cannot
// open many accounts) and the last 4 digits. The name on the BVN must match the account name. Provider outages never change a customer's tier.
// Identity check with a BVN or a NIN (many farmers have a NIN but no BVN). The same rules apply to both: the customer must agree, the name on
// the record must match, 3 unsuccessful tries a day (shared between both), one number can verify only one account, and the number is never stored.
const ID_LABEL={bvn:'BVN',nin:'NIN'};
const idCheck=async(kind,{user:u,body:b})=>{const L=ID_LABEL[kind],num=String(b[kind]||'');
  if(PROD&&kp.isMock())throw new E(501,'Connect an identity provider first (see docs/GOING_LIVE.md)');
  if(!kp.methods().includes(kind))throw new E(501,`${L} checks are not available yet. Please use another method.`);
  if(!/^\d{11}$/.test(num))throw new E(400,`${L} must be 11 digits`);if(b.consent!==true)throw new E(400,'Please agree to the identity check first');
  if(u.kyc_tier>=2)return {tier:u.kyc_tier};
  const today=new Date().setHours(0,0,0,0),h=sec.hmac(num,kind),log=(r,d)=>run('INSERT INTO kyc_checks(user_id,bvn_hash,bvn_last4,result,detail,provider,kind,created_at) VALUES(?,?,?,?,?,?,?,?)',u.id,h,num.slice(-4),r,d||'',kp.providerName(),kind,Date.now());
  if(one("SELECT COUNT(*) n FROM kyc_checks WHERE user_id=? AND result IN('mismatch','not_found') AND created_at>=?",u.id,today).n>=3)throw new E(429,'Too many unsuccessful checks today. Try again tomorrow or contact support.');
  if(one("SELECT 1 x FROM kyc_checks WHERE bvn_hash=? AND result='verified' AND user_id!=?",h,u.id))throw new E(409,`This ${L} is already linked to another account. Contact support.`);
  let r;try{r=await kp.verifyId({kind,id:num,name:u.name,phone:u.phone})}catch(e){console.error('KYC provider error:',e.message);log('error',e.message.slice(0,100));throw new E(503,'Identity check is unavailable right now. Please try again later.')}
  try{log(r.status,r.phoneMatch===false?'phone differs from the record':'')}catch(e){if(/UNIQUE/.test(e.message))throw new E(409,`This ${L} is already linked to another account. Contact support.`);throw e}
  if(r.status=='not_found')throw new E(404,`We could not find that ${L}. Check the number and try again.`);
  if(r.status=='mismatch')throw new E(422,`The name on that ${L} does not match your account name. Check your details or contact support.`);
  run('UPDATE users SET kyc_tier=MAX(kyc_tier,2) WHERE id=?',u.id);notify(u.id,'kyc',`${L} verified`,'Your limits have been raised and loans are unlocked.');return {tier:2}};
route('POST','/api/kyc',c=>idCheck('bvn',c));
route('POST','/api/kyc/nin',c=>idCheck('nin',c));
route('GET','/api/transactions',({user:u})=>{const l=all('SELECT l.id,l.amount,l.kind,l.label,l.ref,l.created_at FROM ledger l JOIN accounts a ON a.id=l.account_id WHERE a.user_id=? ORDER BY l.id DESC LIMIT 50',u.id).map(r=>({...r,amount:r.amount/100})),
  i=all('SELECT i.id,i.amount,i.created_at,g.name FROM interest_log i JOIN goals g ON g.id=i.goal_id WHERE i.user_id=? ORDER BY i.id DESC LIMIT 20',u.id).map(r=>({id:'i'+r.id,amount:r.amount/100,kind:'interest',label:'Savings interest: '+r.name,ref:null,created_at:r.created_at}));
  return {items:[...l,...i].sort((a,b)=>b.created_at-a.created_at).slice(0,50)}});
route('GET','/api/lookup',async({user:u,q})=>{
  if(q.bank&&/^\d{10}$/.test(q.acct||''))return prov.resolveAccount({bank:q.bank,account:q.acct});
  const r=q.acct?one('SELECT u.name,a.user_id FROM accounts a JOIN users u ON u.id=a.user_id WHERE a.number=?',q.acct):q.phone?one('SELECT u.name,u.id user_id FROM users u WHERE u.phone=?',normPhone(q.phone)||'-'):null;
  if(!r)throw new E(404,'Account not found');if(r.user_id==u.id)throw new E(400,'You cannot send money to yourself');return {name:r.name}});

// ---------- payments ----------
route('POST','/api/transfer',(c)=>idem(c,async()=>{
  const {user:u,body:b}=c,a=kobo(b.amount),acc=acctOf(u);verifyPin(u,b.pin);guardMoney(u,acc,a);const rf=ref(),nar=String(b.narration||'').slice(0,60);
  if(b.type=='bank'){
    if(!/^\d{10}$/.test(b.account||'')||!b.bank)throw new E(400,'Enter bank and 10-digit account number');
    const to=await prov.resolveAccount({bank:b.bank,account:b.account});money(()=>tx(()=>post(acc.id,-a,'bank_out',`Transfer to ${to.name}`,rf)));
    const r=await prov.transferToBank({bank:b.bank,account:b.account,amount:a,reference:rf}).catch(()=>({ok:false}));
    if(!r.ok){tx(()=>post(acc.id,a,'reversal','Reversal: failed transfer',rf));throw new E(502,'Transfer failed. You were not charged.')}
    return {status:'success',reference:rf,balance:acctOf(u).balance/100}}
  const to=b.account?one('SELECT a.*,u.name FROM accounts a JOIN users u ON u.id=a.user_id WHERE a.number=?',String(b.account)):one('SELECT a.*,u.name FROM accounts a JOIN users u ON u.id=a.user_id WHERE u.phone=?',normPhone(b.phone)||'-');
  if(!to)throw new E(404,'Recipient not found');if(to.user_id==u.id)throw new E(400,'You cannot send money to yourself');
  money(()=>tx(()=>{post(acc.id,-a,'transfer_out',`Transfer to ${to.name}`,rf);post(to.id,a,'transfer_in',`Transfer from ${u.name}`,rf)}));notify(to.user_id,'money','Money received',`₦${(a/100).toLocaleString()} from ${u.name}`);
  return {status:'success',reference:rf,balance:acctOf(u).balance/100}}));
route('POST','/api/bills/pay',(c)=>idem(c,async()=>{
  const {user:u,body:b}=c,a=kobo(b.amount),acc=acctOf(u),type=String(b.type||'').slice(0,30),cust=String(b.customer||'').trim().slice(0,40);
  if(!type||!cust)throw new E(400,'Enter the bill type and customer number');verifyPin(u,b.pin);guardMoney(u,acc,a);const rf=ref();
  money(()=>tx(()=>post(acc.id,-a,'bill',`${type} payment`,rf)));
  const r=await prov.payBill({type,customer:cust,amount:a,reference:rf}).catch(()=>({ok:false}));
  if(!r.ok){tx(()=>post(acc.id,a,'reversal','Reversal: failed bill',rf));throw new E(502,'Bill payment failed. You were not charged.')}
  return {status:'success',reference:rf}}));
route('POST','/api/dev/fund',({user:u,body:b})=>{if(PROD)throw new E(404,'Not found');const a=kobo(b.amount);tx(()=>post(acctOf(u).id,a,'fund','Wallet funding (sandbox)',ref()));return {balance:acctOf(u).balance/100}});
// Real deposits: your provider calls this when money arrives in a customer's (virtual) account number.
route('POST','/api/webhooks/deposit',({raw,req})=>{const s=process.env.WEBHOOK_SECRET;if(!s)throw new E(503,'Webhook secret not set');
  const sig=crypto.createHmac('sha512',s).update(raw).digest('hex'),h=String(req.headers['x-signature']||'');
  if(h.length!==sig.length||!crypto.timingSafeEqual(Buffer.from(h),Buffer.from(sig)))throw new E(401,'Bad signature');
  const e=JSON.parse(raw),acc=one('SELECT * FROM accounts WHERE number=?',String(e.account));if(!acc)throw new E(404,'Unknown account');
  try{tx(()=>post(acc.id,kobo(e.amount),'fund','Deposit',String(e.reference)))}catch(x){if(!/UNIQUE/.test(x.message))throw x}return {ok:true}},false); // reference makes replays harmless

// ---------- savings ----------

route('GET','/api/savings',({user:u})=>{const rows=all('SELECT * FROM goals WHERE user_id=?',u.id),items=rows.map(g=>({id:g.id,name:g.name,icon:g.icon,saved:g.saved/100,target:g.target/100})),tk=rows.reduce((a,g)=>a+g.saved,0);
  return {items,total:tk/100,ratePct:ratePct(tk),earned:one('SELECT COALESCE(SUM(amount),0) s FROM interest_log WHERE user_id=?',u.id).s/100,pending:rows.reduce((a,g)=>a+g.accrued,0)/1e8}});
route('POST','/api/savings',({user:u,body:b})=>{const t=kobo(b.target);if(t<200000)throw new E(400,'Minimum target is ₦2,000');const n=String(b.name||'').trim().slice(0,40);if(!n)throw new E(400,'Name your goal');
  return {id:Number(run('INSERT INTO goals(user_id,name,icon,target) VALUES(?,?,?,?)',u.id,n,String(b.icon||'🎯').slice(0,4),t).lastInsertRowid)}});
route('POST','/api/savings/:id/deposit',(c)=>idem(c,async()=>{const {user:u,body:b,params:p}=c,a=kobo(b.amount);if(a<200000)throw new E(400,'Minimum deposit is ₦2,000');
  const g=one('SELECT * FROM goals WHERE id=? AND user_id=?',p.id,u.id);if(!g)throw new E(404,'Goal not found');verifyPin(u,b.pin);
  money(()=>tx(()=>{post(acctOf(u).id,-a,'savings',`Saved to ${g.name}`,ref());run('UPDATE goals SET saved=saved+? WHERE id=?',a,g.id)}));return {ok:true}}));

// ---------- loans ----------
route('GET','/api/loans',({user:u})=>{const r=one("SELECT id,principal,months FROM loans WHERE user_id=? AND status='review' ORDER BY id DESC LIMIT 1",u.id);return {...L.assess(u.id),review:r&&{id:r.id,principal:r.principal/100,months:r.months}}});
route('POST','/api/loans/apply',(c)=>idem(c,async()=>{const {user:u,body:b}=c,a=kobo(b.amount),m=Math.round(+b.months);
  if(a<500000||!(m>=1&&m<=12))throw new E(400,'Loans start at ₦5,000 for 1–12 months');verifyPin(u,b.pin);if(one("SELECT 1 x FROM loans WHERE user_id=? AND status='review'",u.id))throw new E(409,'You already have an application under review');
  const d=L.assess(u.id),log=(s)=>run('INSERT INTO loans(user_id,principal,total,months,status,score,reasons,created_at) VALUES(?,?,?,?,?,?,?,?)',u.id,a,L.total(a,m),m,s,d.score,JSON.stringify(d.reasons),Date.now());
  if(d.decision=='decline'){log('declined');notify(u.id,'loan','Loan not approved',d.reasons[0]||'Open the app for details.');return {status:'declined',reasons:d.reasons,score:d.score}}
  if(d.decision=='review'){log('review');notify(u.id,'loan','Loan under review','Our credit team will decide soon. We will message you.');return {status:'review',reasons:d.reasons,score:d.score}}
  if(a>d.limit*100)return {status:'counter_offer',limit:d.limit,score:d.score};
  tx(()=>{if(one("SELECT 1 x FROM loans WHERE user_id=? AND status='active'",u.id))throw new E(409,'You already have an active loan');log('active');post(acctOf(u).id,a,'loan','Loan disbursement',ref())});
  notify(u.id,'loan','Loan approved','₦'+(a/100).toLocaleString()+' has been paid into your account.');return {status:'approved',amount:a/100,total:L.total(a,m)/100,monthly:Math.ceil(L.total(a,m)/m)/100,score:d.score}}));
route('POST','/api/loans/:id/repay',(c)=>idem(c,async()=>{const {user:u,body:b,params:p}=c,a=kobo(b.amount),l=one("SELECT * FROM loans WHERE id=? AND user_id=? AND status='active'",p.id,u.id);
  if(!l)throw new E(404,'No active loan');if(a>l.total-l.paid)throw new E(400,'Amount is more than you owe');verifyPin(u,b.pin);
  money(()=>tx(()=>{post(acctOf(u).id,-a,'loan_repay','Loan repayment',ref());run('UPDATE loans SET paid=paid+?,status=CASE WHEN paid+?>=total THEN \'closed\' ELSE status END WHERE id=?',a,a,l.id)}));return {ok:true}}));

// ---------- savings withdrawals ----------
route('POST','/api/savings/:id/withdraw',(c)=>idem(c,async()=>{const {user:u,body:b,params:p}=c,a=kobo(b.amount),g=one('SELECT * FROM goals WHERE id=? AND user_id=?',p.id,u.id);
  if(!g)throw new E(404,'Goal not found');verifyPin(u,b.pin);
  tx(()=>{if(!run('UPDATE goals SET saved=saved-? WHERE id=? AND saved>=?',a,g.id,a).changes)throw new E(400,'You do not have that much saved in this goal');post(acctOf(u).id,a,'savings_out',`Withdrawn from ${g.name}`,ref())});
  return {ok:true,balance:acctOf(u).balance/100}}));

// ---------- KYC documents ----------
// Tier 1 = signed up. Tier 2 = BVN checked. Tier 3 = ID + selfie reviewed by an admin (highest limits).
// Files are stored OUTSIDE public/ with random names, and only admins can open them.
const UP=path.join(__dirname,'..','uploads'),DOCS={id:'Government ID',selfie:'Selfie holding your ID',address:'Proof of address'};
const sniff=b=>b[0]==0xff&&b[1]==0xd8&&b[2]==0xff?['image/jpeg','.jpg']:b[0]==0x89&&b.slice(1,4).toString()=='PNG'?['image/png','.png']:b.slice(0,4).toString()=='%PDF'?['application/pdf','.pdf']:null;
const clean=s=>String(s||'').replace(/[<>]/g,'').trim();
route('GET','/api/kyc',({user:u})=>({tier:u.kyc_tier,status:u.kyc_status,docs:all("SELECT type,status,note,created_at FROM kyc_docs WHERE user_id=? AND status!='replaced' ORDER BY id",u.id)}));
route('POST','/api/kyc/documents',({user:u,body:b})=>{if(u.kyc_tier<2)throw new E(403,'Verify your BVN first');if(u.kyc_status=='approved')throw new E(400,'You are already fully verified');
  const type=String(b.type);if(!DOCS[type])throw new E(400,'Unknown document type');const buf=Buffer.from(String(b.data||''),'base64');
  if(!buf.length||buf.length>1.2e6)throw new E(400,'File must be under 1 MB');const k=sniff(buf);if(!k)throw new E(400,'Only JPEG, PNG or PDF files are accepted');
  const file=crypto.randomBytes(16).toString('hex')+k[1];fs.mkdirSync(UP,{recursive:true,mode:0o700});fs.writeFileSync(path.join(UP,file),buf,{mode:0o600});
  tx(()=>{run("UPDATE kyc_docs SET status='replaced' WHERE user_id=? AND type=? AND status IN('pending','rejected')",u.id,type);
    run('INSERT INTO kyc_docs(user_id,type,file,mime,size,status,created_at) VALUES(?,?,?,?,?,?,?)',u.id,type,file,k[0],buf.length,'pending',Date.now());
    const has=t=>one("SELECT 1 x FROM kyc_docs WHERE user_id=? AND type=? AND status='pending'",u.id,t);if(has('id')&&has('selfie'))run("UPDATE users SET kyc_status='pending' WHERE id=?",u.id)});
  if(one('SELECT kyc_status s FROM users WHERE id=?',u.id).s=='pending')notify(u.id,'info','Documents received','We will review your ID and selfie within 24 hours.');return {ok:true}},true,1.7e6);

// ---------- marketplace ----------
const CATS=['Grains','Vegetables','Livestock','Other'],UNITS=['100kg bag','50kg bag','25kg bag','basket','crate','each','kg'];
const icon=c=>({Grains:'🌾',Vegetables:'🍅',Livestock:'🐐',Other:'🧺'})[c];
route('GET','/api/market/listings',({user:u})=>({items:all("SELECT l.*,u.name seller FROM listings l JOIN users u ON u.id=l.seller_id WHERE l.status='active' AND l.qty>0 ORDER BY l.id DESC LIMIT 100").map(l=>({id:l.id,name:l.name,icon:l.icon,category:l.category,price:l.price/100,unit:l.unit,qty:l.qty,location:l.location,seller:l.seller,mine:l.seller_id==u.id}))}));
route('POST','/api/market/listings',({user:u,body:b})=>{const name=clean(b.name).slice(0,40),loc=clean(b.location).slice(0,40),qty=Math.round(+b.qty),cat=CATS.includes(b.category)?b.category:'Other';
  if(name.length<2)throw new E(400,'Enter the produce name');if(!UNITS.includes(b.unit))throw new E(400,'Choose a unit');if(!(qty>=1&&qty<=100000))throw new E(400,'Enter how many units you have');
  return {id:Number(run('INSERT INTO listings(seller_id,name,icon,category,price,unit,qty,location,created_at) VALUES(?,?,?,?,?,?,?,?,?)',u.id,name,icon(cat),cat,kobo(b.price),b.unit,qty,loc||'Nigeria',Date.now()).lastInsertRowid)}});
route('POST','/api/market/listings/:id/remove',({user:u,params:p})=>{if(!run("UPDATE listings SET status='removed' WHERE id=? AND seller_id=? AND status IN('active','sold')",p.id,u.id).changes)throw new E(404,'Listing not found');return {ok:true}});
route('POST','/api/market/orders',(c)=>idem(c,async()=>{const {user:u,body:b}=c,qty=Math.round(+b.qty),acc=acctOf(u);if(!(qty>=1&&qty<=1000))throw new E(400,'Enter a quantity');verifyPin(u,b.pin);const rf=mk.ref();
  money(()=>tx(()=>{const li=one("SELECT * FROM listings WHERE id=? AND status='active'",b.listingId);if(!li)throw new E(404,'This produce is no longer available');
    if(li.seller_id==u.id)throw new E(400,'You cannot buy your own produce');if(li.qty<qty)throw new E(409,`Only ${li.qty} left`);
    const amt=li.price*qty;guardMoney(u,acc,amt);post(acc.id,-amt,'market_pay',`Order: ${li.name}`,rf);post(one("SELECT id FROM accounts WHERE number='ESCROW'").id,amt,'escrow_in','Held for '+rf,rf);
    run("UPDATE listings SET qty=qty-?,status=CASE WHEN qty-?<=0 THEN 'sold' ELSE status END WHERE id=?",qty,qty,li.id);
    run('INSERT INTO orders(ref,listing_id,buyer_id,seller_id,item,qty,amount,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)',rf,li.id,u.id,li.seller_id,li.name,qty,amt,'escrow',Date.now())}));
  const od=one('SELECT * FROM orders WHERE ref=?',rf);notify(od.seller_id,'order','New order',`${od.qty} x ${od.item} for ₦${(od.amount/100).toLocaleString()}. Ship it to get paid.`);return {status:'escrow',reference:rf}}));
const ordView=(o,me)=>({id:o.id,ref:o.ref,item:o.item,qty:o.qty,amount:o.amount/100,status:o.status,reason:o.dispute_reason,note:o.note,created_at:o.created_at,other:me==o.buyer_id?o.seller:o.buyer});
route('GET','/api/market/orders',({user:u})=>{const q=col=>all(`SELECT o.*,s.name seller,b.name buyer FROM orders o JOIN users s ON s.id=o.seller_id JOIN users b ON b.id=o.buyer_id WHERE o.${col}=? ORDER BY o.id DESC LIMIT 50`,u.id).map(o=>ordView(o,u.id));return {buying:q('buyer_id'),selling:q('seller_id')}});
route('POST','/api/market/orders/:id/ship',({user:u,params:p})=>{if(!run("UPDATE orders SET status='shipped',shipped_at=? WHERE id=? AND seller_id=? AND status='escrow'",Date.now(),p.id,u.id).changes)throw new E(404,'Order not found');const so=one('SELECT * FROM orders WHERE id=?',p.id);notify(so.buyer_id,'order','Order shipped',`${so.item} is on its way. Confirm when it arrives.`);return {ok:true}});
route('POST','/api/market/orders/:id/confirm',({user:u,params:p})=>{if(!one("SELECT 1 x FROM orders WHERE id=? AND buyer_id=? AND status IN('escrow','shipped')",p.id,u.id))throw new E(404,'Order not found');mk.release(+p.id);return {ok:true}});
route('POST','/api/market/orders/:id/dispute',({user:u,params:p,body:b})=>{const why=clean(b.reason).slice(0,200);if(why.length<3)throw new E(400,'Tell us what went wrong');
  if(!run("UPDATE orders SET status='disputed',dispute_reason=? WHERE id=? AND buyer_id=? AND status IN('escrow','shipped')",why,p.id,u.id).changes)throw new E(404,'Order not found');const dd=one('SELECT * FROM orders WHERE id=?',p.id);notify(dd.seller_id,'order','Dispute opened',`The buyer reported a problem with ${dd.item}. Our team will review it.`);return {ok:true}});
// Cancel an order that has NOT shipped yet: either side can do it, and the buyer is refunded in full.
route('POST','/api/market/orders/:id/cancel',(c)=>idem(c,async()=>{const {user:u,params:p}=c,o=one('SELECT * FROM orders WHERE id=? AND (buyer_id=? OR seller_id=?)',p.id,u.id,u.id);if(!o)throw new E(404,'Order not found');
  if(o.status!=='escrow')throw new E(409,o.status=='shipped'?'This order has shipped. Use Report a problem if something is wrong.':'This order can no longer be cancelled');
  const byBuyer=o.buyer_id==u.id;if(!mk.refund(o.id,['escrow']))throw new E(409,'This order can no longer be cancelled');
  run('UPDATE orders SET note=? WHERE id=?',byBuyer?'Cancelled by the buyer':'Declined by the seller',o.id);
  notify(byBuyer?o.seller_id:o.buyer_id,'order','Order cancelled',byBuyer?`${o.item} was cancelled by the buyer.`:`${o.item} was declined by the seller and you have been refunded.`);return {ok:true}}));
// ---------- alerts inbox ----------
route('GET','/api/notifications',({user:u})=>({items:all('SELECT id,kind,title,body,read_at,created_at FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 40',u.id),unread:one('SELECT COUNT(*) n FROM notifications WHERE user_id=? AND read_at IS NULL',u.id).n}));
route('POST','/api/notifications/read',({user:u})=>{run('UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL',Date.now(),u.id);return {ok:true}});
route('POST','/api/notifications/prefs',({user:u,body:b})=>{run('UPDATE users SET notify_sms=? WHERE id=?',b.sms?1:0,u.id);return {smsAlerts:!!b.sms}});
route('GET','/api/push/config',()=>pushConfig());
route('POST','/api/push/subscriptions',({user:u,body:b})=>{
  if(!pushConfig().enabled)throw new E(503,'Push notifications are not configured on this server');
  const endpoint=String(b.endpoint||''),keys=b.keys||{};let parsed;
  try{parsed=new URL(endpoint)}catch{throw new E(400,'Invalid push subscription')}
  const p256dh=String(keys.p256dh||''),auth=String(keys.auth||''),locale=['en','ha','yo','ig','pcm','ar'].includes(b.locale)?b.locale:'en';
  const pushHosts=['fcm.googleapis.com','push.services.mozilla.com','updates.push.services.mozilla.com','web.push.apple.com','wns.windows.com'];
  if(parsed.protocol!=='https:'||parsed.port&&parsed.port!=='443'||parsed.username||parsed.password||parsed.hash||!pushHosts.some(h=>parsed.hostname===h||parsed.hostname.endsWith('.'+h))||endpoint.length>2000||!/^[-_A-Za-z0-9]{40,180}$/.test(p256dh)||!/^[-_A-Za-z0-9]{16,100}$/.test(auth))throw new E(400,'Invalid push subscription');
  const owner=one('SELECT user_id FROM push_subscriptions WHERE endpoint=?',endpoint);
  if(owner&&owner.user_id!==u.id)throw new E(409,'This browser notification subscription belongs to another account');
  if(!owner&&one('SELECT COUNT(*) n FROM push_subscriptions WHERE user_id=?',u.id).n>=10)throw new E(429,'Too many devices are registered for push notifications');
  run('INSERT INTO push_subscriptions(user_id,endpoint,p256dh,auth,locale,created_at) VALUES(?,?,?,?,?,?) ON CONFLICT(endpoint) DO UPDATE SET p256dh=excluded.p256dh,auth=excluded.auth,locale=excluded.locale,created_at=excluded.created_at',u.id,endpoint,p256dh,auth,locale,Date.now());
  return {ok:true}
});
route('POST','/api/push/unsubscribe',({user:u,body:b})=>{const endpoint=String(b.endpoint||'');if(!endpoint||endpoint.length>2000)throw new E(400,'Invalid push subscription');run('DELETE FROM push_subscriptions WHERE user_id=? AND endpoint=?',u.id,endpoint);return {ok:true}});
route('POST','/api/harvest',({user:u,body:b})=>{const p=Math.round(+b.pct);if(!(p>=0&&p<=50))throw new E(400,'Choose 0 to 50 percent');run('UPDATE users SET harvest_pct=? WHERE id=?',p,u.id);return {ok:true}});

// ---------- admin (role = admin; every decision is written to admin_log) ----------
const admin=fn=>c=>{if(c.user.role!=='admin')throw new E(403,'Admins only');return fn(c)};
const audit=(c,action,target,detail)=>run('INSERT INTO admin_log(admin_id,action,target,detail,created_at) VALUES(?,?,?,?,?)',c.user.id,action,String(target),String(detail||'').slice(0,300),Date.now());
route('GET','/api/admin/stats',admin(()=>({users:one("SELECT COUNT(*) n FROM users WHERE role='user'").n,wallets:one('SELECT COALESCE(SUM(balance),0) s FROM accounts WHERE user_id>0').s/100,escrow:one("SELECT balance b FROM accounts WHERE number='ESCROW'").b/100,
  loansOut:one("SELECT COALESCE(SUM(total-paid),0) s FROM loans WHERE status='active'").s/100,loanReviews:one("SELECT COUNT(*) n FROM loans WHERE status='review'").n,kycPending:one("SELECT COUNT(*) n FROM users WHERE kyc_status='pending'").n,disputes:one("SELECT COUNT(*) n FROM orders WHERE status='disputed'").n,smsFailed:one("SELECT COUNT(*) n FROM notifications WHERE sms_state='failed'").n})));
route('POST','/api/admin/sms/retry',admin(c=>{const r=run("UPDATE notifications SET sms_state='pending',sms_attempts=0,sms_next=NULL WHERE sms_state='failed' AND created_at>=?",Date.now()-864e5);audit(c,'sms_retry','-',r.changes+' texts');flushSms().catch(()=>{});return {requeued:r.changes}}));
route('GET','/api/admin/loans',admin(()=>({items:all("SELECT l.*,u.name,u.email,u.phone,u.kyc_tier FROM loans l JOIN users u ON u.id=l.user_id WHERE l.status='review' ORDER BY l.id").map(l=>({id:l.id,user_id:l.user_id,name:l.name,email:l.email,phone:l.phone,tier:l.kyc_tier,amount:l.principal/100,total:l.total/100,months:l.months,score:l.score,reasons:JSON.parse(l.reasons||'[]'),created_at:l.created_at,current:L.assess(l.user_id)}))})));
route('POST','/api/admin/loans/:id/decide',admin(c=>{const l=one("SELECT * FROM loans WHERE id=? AND status='review'",c.params.id),d=c.body.decision,note=clean(c.body.note).slice(0,200);if(!l)throw new E(404,'No such loan awaiting review');
  if(l.user_id==c.user.id)throw new E(403,'You cannot decide your own loan');if(d!='approve'&&d!='decline')throw new E(400,'Choose approve or decline');
  tx(()=>{if(d=='approve'){if(one("SELECT 1 x FROM loans WHERE user_id=? AND status='active'",l.user_id))throw new E(409,'Customer already has an active loan');
      run("UPDATE loans SET status='active',decided_by=?,decided_at=?,note=? WHERE id=?",c.user.id,Date.now(),note,l.id);post(acctOf({id:l.user_id}).id,l.principal,'loan','Loan disbursement',ref())}
    else run("UPDATE loans SET status='declined',decided_by=?,decided_at=?,note=? WHERE id=?",c.user.id,Date.now(),note,l.id);audit(c,'loan_'+d,l.id,note)});notify(l.user_id,'loan',d=='approve'?'Loan approved':'Loan not approved',d=='approve'?'₦'+(l.principal/100).toLocaleString()+' has been paid into your account.':(note||'Your application was declined.'));return {ok:true}}));
route('GET','/api/admin/kyc',admin(()=>({items:all("SELECT id,name,email,phone,kyc_tier FROM users WHERE kyc_status='pending'").map(u=>({...u,docs:all("SELECT id,type,mime,created_at FROM kyc_docs WHERE user_id=? AND status='pending'",u.id)}))})));
route('GET','/api/admin/kyc/file/:id',admin(c=>{const d=one('SELECT * FROM kyc_docs WHERE id=?',c.params.id);if(!d)throw new E(404,'Not found');audit(c,'kyc_view',d.user_id,d.type);return {__file:path.join(UP,d.file),mime:d.mime}}));
route('POST','/api/admin/kyc/:uid/decide',admin(c=>{const u=one("SELECT * FROM users WHERE id=? AND kyc_status='pending'",c.params.uid),d=c.body.decision,note=clean(c.body.note).slice(0,200);if(!u)throw new E(404,'Nothing to review');if(u.id==c.user.id)throw new E(403,'You cannot review your own documents');
  if(d!='approve'&&d!='reject')throw new E(400,'Choose approve or reject');if(d=='reject'&&!note)throw new E(400,'Give the customer a reason');
  tx(()=>{run("UPDATE kyc_docs SET status=?,note=? WHERE user_id=? AND status='pending'",d=='approve'?'approved':'rejected',note,u.id);run('UPDATE users SET kyc_tier=?,kyc_status=? WHERE id=?',d=='approve'?3:u.kyc_tier,d=='approve'?'approved':'rejected',u.id);audit(c,'kyc_'+d,u.id,note)});notify(u.id,'kyc',d=='approve'?'Identity verified':'Identity check needs attention',d=='approve'?'Your limits have been raised.':note);return {ok:true}}));
route('GET','/api/admin/disputes',admin(()=>({items:all("SELECT o.*,s.name seller,b.name buyer FROM orders o JOIN users s ON s.id=o.seller_id JOIN users b ON b.id=o.buyer_id WHERE o.status='disputed' ORDER BY o.id").map(o=>({id:o.id,ref:o.ref,item:o.item,qty:o.qty,amount:o.amount/100,buyer:o.buyer,seller:o.seller,reason:o.dispute_reason,created_at:o.created_at}))})));
route('POST','/api/admin/disputes/:id/resolve',admin(c=>{const o=one("SELECT * FROM orders WHERE id=? AND status='disputed'",c.params.id),d=c.body.outcome,note=clean(c.body.note).slice(0,200);if(!o)throw new E(404,'No such dispute');
  if(o.buyer_id==c.user.id||o.seller_id==c.user.id)throw new E(403,'You are a party to this order');if(d!='refund'&&d!='release')throw new E(400,'Choose refund or release');
  // refund()/release() are already atomic on their own (and refuse an order that has moved on), so no outer transaction here.
  if(!(d=='refund'?mk.refund(o.id):mk.release(o.id)))throw new E(409,'This order was already settled');run('UPDATE orders SET note=? WHERE id=?',note,o.id);audit(c,'dispute_'+d,o.id,note);for(const [uid,who] of [[o.buyer_id,'b'],[o.seller_id,'s']])notify(uid,'dispute','Dispute resolved',`${o.item}: ${d=='refund'?(who=='b'?'you were refunded':'the buyer was refunded'):(who=='b'?'the seller was paid':'you were paid')}.${note?' '+note:''}`);return {ok:true}}));

// ---------- http plumbing ----------
const hits=new Map(),MIME={'.html':'text/html','.css':'text/css','.js':'text/javascript','.svg':'image/svg+xml','.png':'image/png','.md':'text/plain','.webmanifest':'application/manifest+json'};
const send=(res,s,o)=>{res.writeHead(s,{'Content-Type':'application/json'});res.end(JSON.stringify(o))};
const server=http.createServer(async(req,res)=>{
  res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data: blob:");
  try{const url=new URL(req.url,'http://x');
    // Keep this app's API separate from the workspace's shared /api service route.
    if(url.pathname.startsWith('/gidan-api/'))url.pathname='/api/'+url.pathname.slice('/gidan-api/'.length);
    if(!url.pathname.startsWith('/api/')){let f=path.normalize(path.join(PUB,url.pathname==='/'?'index.html':url.pathname));
      if(!f.startsWith(PUB)||!fs.existsSync(f)||fs.statSync(f).isDirectory()){res.writeHead(404);return res.end('Not found')}
      res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});return fs.createReadStream(f).pipe(res)}
    const r=R.find(x=>x.m===req.method&&x.re.test(url.pathname));if(!r)return send(res,404,{error:'Not found'});
    if(url.pathname.startsWith('/api/auth/')){const ip=(process.env.TRUST_PROXY?String(req.headers['x-forwarded-for']||'').split(',')[0].trim():'')||req.socket.remoteAddress,t=Date.now(),h=(hits.get(ip)||[]).filter(x=>t-x<6e4);h.push(t);hits.set(ip,h);if(h.length>(+process.env.AUTH_RATE_LIMIT||20))return send(res,429,{error:'Too many requests'})}
    let user=null;if(r.auth){const p=sec.verify((req.headers.authorization||'').replace('Bearer ',''));user=p&&one('SELECT * FROM users WHERE id=?',p.uid);if(user&&p.ver!==user.token_ver)user=null;if(!user)return send(res,401,{error:'Please sign in'})}
    let raw='';if(req.method==='POST'){for await(const ch of req){raw+=ch;if(raw.length>r.max)return send(res,413,{error:'Too large'})}}
    let body={};try{body=raw?JSON.parse(raw):{}}catch{return send(res,400,{error:'Invalid JSON'})}
    const out=await r.fn({req,user,body,raw,q:Object.fromEntries(url.searchParams),params:r.re.exec(url.pathname).groups||{}});
    if(out&&out.__file){res.writeHead(200,{'Content-Type':out.mime,'Cache-Control':'no-store','Content-Disposition':'inline'});return fs.createReadStream(out.__file).pipe(res)}
    send(res,200,out);
  }catch(e){if(e instanceof E)return send(res,e.s,{error:e.message});console.error(e);send(res,500,{error:'Something went wrong'})}});
if(require.main===module){const P=process.env.PORT||3000;
  if(PROD&&!msg.live)console.warn('WARNING: password-reset codes are only printed to the console. Configure server/messenger.js before going live.');
  server.listen(P,()=>{console.log(`Gidan asusu running on http://localhost:${P}${PROD?'':'  (sandbox mode)'}`);
    if(process.env.JOBS!=='off'){const tick=()=>{flushSms().catch(()=>{});try{const s=mk.settleOrders();if(s.released||s.refunded)console.log('order settlement:',s);const r=jobs.runDue();if(r.accrued||r.paid)console.log('interest job:',r)}catch(e){console.error('interest job failed:',e.message)}};tick();setInterval(tick,36e5);setInterval(()=>flushSms().catch(()=>{}),6e4)}})}
module.exports={server};
