// Password/PIN hashing (scrypt) and signed tokens (HS256 JWT) using only Node's crypto.
const crypto=require('crypto'),fs=require('fs');
const SECRET=process.env.JWT_SECRET||(()=>{try{return fs.readFileSync('.secret','utf8')}catch{const s=crypto.randomBytes(48).toString('hex');fs.writeFileSync('.secret',s,{mode:0o600});return s}})();
const b64=b=>Buffer.from(b).toString('base64url'),mac=d=>crypto.createHmac('sha256',SECRET).update(d).digest('base64url');
const hash=p=>{const s=crypto.randomBytes(16);return s.toString('hex')+':'+crypto.scryptSync(p,s,64).toString('hex')};
const check=(p,h)=>{const [s,k]=h.split(':'),d=crypto.scryptSync(p,Buffer.from(s,'hex'),64);return crypto.timingSafeEqual(d,Buffer.from(k,'hex'))};
const sign=(p,ttl=3600)=>{const h=b64('{"alg":"HS256","typ":"JWT"}'),b=b64(JSON.stringify({...p,exp:Math.floor(Date.now()/1000)+ttl}));return h+'.'+b+'.'+mac(h+'.'+b)};
const verify=t=>{try{const [h,b,s]=t.split('.'),e=mac(h+'.'+b);if(s.length!==e.length||!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(e)))return null;const p=JSON.parse(Buffer.from(b,'base64url'));return p.exp>Date.now()/1000?p:null}catch{return null}};
const DUMMY=hash('dummy');
// Keyed hash so a BVN can be compared (is it already used?) without ever storing the BVN itself.
const hmac=(s,kind='bvn')=>crypto.createHmac('sha256',SECRET).update(kind+':'+s).digest('hex');
module.exports={hash,check,sign,verify,hmac,DUMMY};
