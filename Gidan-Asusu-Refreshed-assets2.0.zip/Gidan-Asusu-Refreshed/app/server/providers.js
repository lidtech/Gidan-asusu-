// Payment-provider adapter. "mock" runs in sandbox. To go live, implement the same 3 functions
// against your licensed partner (Paystack, Flutterwave, Monnify, a BaaS bank...) and set PROVIDER.
// Always check the partner's current API docs; the shapes below are placeholders.
const mock={
  async resolveAccount({bank,account}){return {name:'Sandbox Account '+account.slice(-4)}},
  async transferToBank({bank,account,amount,reference}){return {ok:true,ref:'MOCK-'+reference}},
  async payBill({type,customer,amount,reference}){return {ok:true,ref:'MOCK-'+reference}}
};
const live=()=>{throw new Error('Live payment provider not configured. Implement server/providers.js')};
module.exports=process.env.PROVIDER&&process.env.PROVIDER!=='mock'?{resolveAccount:live,transferToBank:live,payBill:live}:mock;
