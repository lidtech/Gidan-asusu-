// Drives the real frontend code (with a fake DOM) against the real server. Run: node server/ui-smoke.js
process.env.DB_FILE=':memory:';process.env.JWT_SECRET='t';
const fs=require('fs'),vm=require('vm'),{server}=require('./server');
server.listen(0,async()=>{const base='http://localhost:'+server.address().port;
 const el=()=>({innerHTML:'',dataset:{},value:'',style:{},appendChild(){},remove(){},querySelector:()=>null,scrollTo(){}});const ids={};
 const ctx={process,setInterval,console,setTimeout,Date,Math,JSON,Promise,URL,crypto:require('crypto').webcrypto,localStorage:{d:{},getItem(k){return this.d[k]||null},setItem(k,v){this.d[k]=v},removeItem(k){delete this.d[k]}},sessionStorage:{d:{},getItem(k){return this.d[k]||null},setItem(k,v){this.d[k]=v},removeItem(k){delete this.d[k]}},
  fetch:(u,o)=>fetch(base+u,o),prompt:()=>null,alert(){},
  document:{getElementById:i=>ids[i]||(ids[i]=el()),createElement:el,querySelectorAll:()=>[]}};
 ctx.document.getElementById('app').dataset.s='home';vm.createContext(ctx);
 const html=fs.readFileSync(__dirname+'/../public/index.html','utf8'),files=[...html.matchAll(/src="([^"]+)"/g)].map(m=>m[1]);
 const src=files.map(f=>fs.readFileSync(__dirname+'/../public/'+f,'utf8')).join('\n')+`
 ;(async()=>{const set=(i,v)=>document.getElementById(i).value=v,log=[];let ok=true;const chk=(n,c)=>{log.push((c?'  ✓ ':'  ✗ ')+n);if(!c)ok=false};
  set('f_name','Israel Okocha');set('f_phone','08031112222');set('f_email','isr@x.com');set('f_pw','Passw0rd1');set('f_pin','1234');await doSignup();
  chk('signup logs in and loads profile',user.name=='Israel Okocha'&&acct.number.length==10);
  set('fa','100000');await devFund();chk('sandbox funding updates balance',bal==100000);
  const b=await api('/auth/signup',{body:{name:'Tunde Yusuf',phone:'08033334444',email:'t@x.com',password:'Passw0rd1',pin:'4321'}});
  tt='other';set('ph','08033334444');set('amt','25000');await resolveRc();chk('recipient name resolves',rname=='Tunde Yusuf');
  sendMoney();set('pin','1234');pinOk();await new Promise(r=>setTimeout(r,300));chk('transfer via PIN updates balance and history',bal==75000&&tx[0][3]==-25000&&lastTx.n=='Tunde Yusuf');
  goals=[];await api('/savings',{body:{name:'Home',target:50000,icon:'🏠'}});await refresh();set('ga','5000');addGoal(0);set('pin','1234');pinOk();await new Promise(r=>setTimeout(r,300));chk('savings deposit',bal==70000&&goals[0][1]==5000);
  set('bn','12345678');set('ba','2000');confirmBill('Data');set('pin','1234');pinOk();await new Promise(r=>setTimeout(r,300));chk('bill payment',bal==68000&&billList[0][0]=='Data');
  chk('esc() neutralises HTML',!/[<>"']/.test(esc('<img onerror="x">')));
  const asIsrael=sessionStorage.getItem('tk'),asTunde=b.token,wait=ms=>new Promise(r=>setTimeout(r,ms));
  set('ga','2000');withdrawGoal(0);set('pin','1234');pinOk();await wait(300);chk('withdraw from a goal returns money to the wallet',bal==70000&&goals[0][1]==3000);
  sessionStorage.setItem('tk',asTunde);await refresh();await setHarvest(10);
  set('sn','Sorghum');set('sp','10000');set('su','50kg bag');set('sq','5');set('sl','Kano');set('sc','Grains');await sellItem();chk('seller lists produce',mk.listings.some(x=>x.name=='Sorghum'&&x.mine));
  sessionStorage.setItem('tk',asIsrael);await refresh();await loadMarket();const li=mk.listings.find(x=>x.name=='Sorghum');chk('buyer sees the listing',!!li&&!li.mine);
  set('bq','2');buyNow(li.id);set('pin','1234');pinOk();await wait(400);chk('order placed and money held',bal==50000&&mk.buying[0].status=='escrow');
  const oid=mk.buying[0].id;sessionStorage.setItem('tk',asTunde);await refresh();await loadMarket();await ordAct(oid,'ship');chk('seller ships',mk.selling[0].status=='shipped');
  sessionStorage.setItem('tk',asIsrael);await refresh();await loadMarket();await ordAct(oid,'confirm');chk('buyer confirms delivery',mk.buying[0].status=='completed');
  sessionStorage.setItem('tk',asTunde);await refresh();chk('seller paid and 10 percent auto-saved',goals.some(x=>x[0]=='Harvest Savings'&&x[1]==2000));
  sessionStorage.setItem('tk',asIsrael);await refresh();
  set('bq','1');buyNow(li.id);set('pin','1234');pinOk();await wait(400);const held=bal,oid2=mk.buying[0].id;chk('second order placed',mk.buying[0].status=='escrow');
  await ordAct(oid2,'cancel');chk('buyer cancels an unshipped order and is refunded',bal==held+10000&&mk.buying[0].status=='refunded');
  await openInbox();chk('notification inbox loads',nt.items.length>0&&A.dataset.s=='inbox');
  idm=['bvn','nin'];try{verifyBvn();idKind='nin';verifyBvn();chk('identity sheet opens for BVN and NIN',true)}catch(e){chk('identity sheet opens for BVN and NIN ('+e.message+')',false)}
  setLanguage('ar');chk('Arabic language is remembered and uses Arabic labels',lg=='ar'&&localStorage.getItem('gidan-language')=='ar'&&S.lang().includes('اختر لغة التطبيق')&&localizeText('Recent Transactions')=='أحدث المعاملات'&&localizeText('Acct 1234567890 · Gidan asusu')=='الحساب 1234567890 · جي دان أسوسو');
  for(const c of ['ha','yo','ig','pcm']){setLanguage(c);const T=TR[c];
    chk(c+': pack is complete (dictionary and '+TRX.length+' templates)',Object.keys(T.d).length>=356&&T.p.length==TRX.length&&T.p.every(x=>typeof x=='string'&&x.length>0));
    chk(c+': labels, language screen and RTL flag',lg==c&&localStorage.getItem('gidan-language')==c&&t('choose')!=L.en.choose&&S.lang().includes(t('choose'))&&!document.documentElement?.dir);
    chk(c+': static text, dynamic text and dates localize',localizeText('Recent Transactions')==T.d['Recent Transactions']&&localizeText('Transfer to Ada Obi')!='Transfer to Ada Obi'&&localizeText('Transfer to Ada Obi').includes('Ada Obi')&&!/\bJan\b/.test(localizeText('Jan 5, 2026'))&&localizeText('Hello world')=='Hello world'&&localizeText('constructor')=='constructor');
    chk(c+': amounts, names and codes survive templates',localizeText('₦5,000 has been sent to Ada Obi').includes('₦5,000')&&localizeText('₦5,000 has been sent to Ada Obi').includes('Ada Obi')&&localizeText('Sandbox code: 123456').includes('123456')&&localizeText('Earning 8% a year · ₦1,200 interest paid so far').includes('₦1,200'));
    for(const k of Object.keys(S)){try{S[k]()}catch(e){chk(c+': render '+k+' ('+e.message+')',false)}}}
  setLanguage('en');chk('English leaves text untouched',localizeText('Recent Transactions')=='Recent Transactions');
  setLanguage('ar');chk('Arabic: members, request and score suffix',localizeText('42 members')=='42 عضوًا'&&localizeText('Request sent to Kano Pepper Co-op').includes('Kano Pepper Co-op')&&localizeText('Keep saving to qualify · score 40/100').endsWith('40/100'));
  for(const s of Object.keys(S)){try{S[s]()}catch(e){chk('render '+s+' ('+e.message+')',false)}}chk('all screens render',true);
  logout();chk('logout clears session',!sessionStorage.getItem('tk'));
  console.log(log.join('\\n'));console.log(ok?'UI SMOKE TEST PASSED':'UI SMOKE TEST FAILED');})().then(()=>process.exit(0));`;
 vm.runInContext(src,ctx);});
