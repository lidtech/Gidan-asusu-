// Marketplace escrow: buyer's money moves to ESCROW at purchase, then is RELEASED to the seller
// (minus optional fee, with Harvest Savings auto-save) or REFUNDED to the buyer. Every move is atomic.
const crypto=require('crypto'),{tx,one,all,run,post}=require('./db'),{notify}=require('./notify');
const naira=k=>'₦'+(k/100).toLocaleString();
const FEE_BPS=+(process.env.MARKET_FEE_BPS||0);            // e.g. 150 = 1.5% fee on each sale (default 0)
const ref=()=>'ORD'+crypto.randomBytes(5).toString('hex').toUpperCase();
const sys=n=>one('SELECT * FROM accounts WHERE number=?',n);
function release(id){return tx(()=>{const o=one("SELECT * FROM orders WHERE id=? AND status IN('escrow','shipped','disputed')",id);if(!o)return false;
  const fee=Math.floor(o.amount*FEE_BPS/10000),net=o.amount-fee,sa=one('SELECT * FROM accounts WHERE user_id=?',o.seller_id);
  post(sys('ESCROW').id,-o.amount,'escrow_out','Order '+o.ref+' released',o.ref);post(sa.id,net,'sale','Sale: '+o.item,o.ref);if(fee)post(sys('PLATFORM').id,fee,'fee','Fee '+o.ref,o.ref);
  const pct=one('SELECT harvest_pct p FROM users WHERE id=?',o.seller_id).p,share=Math.floor(net*pct/100);
  if(share>0){let g=one("SELECT * FROM goals WHERE user_id=? AND name='Harvest Savings'",o.seller_id);
    if(!g){run("INSERT INTO goals(user_id,name,icon,target) VALUES(?,?,?,?)",o.seller_id,'Harvest Savings','🧺',100000000);g=one("SELECT * FROM goals WHERE user_id=? AND name='Harvest Savings'",o.seller_id)}
    post(sa.id,-share,'savings','Harvest Savings auto-save',o.ref);run('UPDATE goals SET saved=saved+? WHERE id=?',share,g.id)}
  run("UPDATE orders SET status='completed',completed_at=? WHERE id=?",Date.now(),id);
  notify(o.seller_id,'money','Payment received',`${naira(net)} for ${o.item}`);notify(o.buyer_id,'order','Order completed',`${o.item}: the seller has been paid.`);return true})}
function refund(id,from=['escrow','shipped','disputed']){return tx(()=>{const o=one(`SELECT * FROM orders WHERE id=? AND status IN (${from.map(()=>'?').join(',')})`,id,...from);if(!o)return false;
  post(sys('ESCROW').id,-o.amount,'escrow_out','Order '+o.ref+' refunded',o.ref);post(one('SELECT * FROM accounts WHERE user_id=?',o.buyer_id).id,o.amount,'refund','Refund: '+o.item,o.ref);
  run("UPDATE listings SET qty=qty+?,status=CASE WHEN status='sold' THEN 'active' ELSE status END WHERE id=?",o.qty,o.listing_id);
  run("UPDATE orders SET status='refunded',completed_at=? WHERE id=?",Date.now(),id);
  notify(o.buyer_id,'money','Refund received',`${naira(o.amount)} for ${o.item} is back in your wallet.`);return true})}
// Run hourly: shipped orders auto-release after 7 days; orders never shipped are refunded after 14 days. Disputes wait for an admin.
function settleOrders(now=Date.now()){let r=0,f=0;
  for(const o of all("SELECT id FROM orders WHERE status='shipped' AND shipped_at<?",now-7*864e5))if(release(o.id))r++;
  for(const o of all("SELECT id FROM orders WHERE status='escrow' AND created_at<?",now-14*864e5))if(refund(o.id))f++;return {released:r,refunded:f}}
module.exports={release,refund,settleOrders,ref,FEE_BPS};
