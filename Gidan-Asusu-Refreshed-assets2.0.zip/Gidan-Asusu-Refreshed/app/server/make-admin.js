// Give an existing user admin rights: npm run make-admin -- you@example.com
const {run,one}=require('./db'),e=String(process.argv[2]||'').toLowerCase();
if(!one('SELECT 1 x FROM users WHERE email=?',e)){console.error('No user with that email. Sign up in the app first.');process.exit(1)}
run("UPDATE users SET role='admin',token_ver=token_ver+1 WHERE email=?",e);console.log(e,'is now an admin. They must sign in again.');
