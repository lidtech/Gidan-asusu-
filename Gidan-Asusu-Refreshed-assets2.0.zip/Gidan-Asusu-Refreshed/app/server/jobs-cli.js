// Run the interest job by hand or from cron: npm run jobs
console.log(require('./jobs').runDue(),require('./market').settleOrders());
