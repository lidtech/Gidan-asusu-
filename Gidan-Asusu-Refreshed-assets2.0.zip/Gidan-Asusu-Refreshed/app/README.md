# Gidan asusu: mobile banking app (frontend + backend)

Needs **Node 22.5+** and `npm install` for the Web Push delivery library. No separate database server is needed.

```
npm install
npm start      # http://localhost:3000  (sandbox mode)
npm test       # API checks + an app-screen test that drives real flows
npm run jobs   # run the savings-interest job by hand
npm run seed   # sandbox: add demo produce to the marketplace
npm run make-admin -- you@example.com   # give an account admin rights (sign up in the app first)
```
Open http://localhost:3000, tap Create an Account, then More → Add Money (sandbox) to get test money.

```
public/            the app screens (HTML/CSS/JS). js/core/api.js talks to the server
server/server.js   API routes: auth, transfers, bills, savings, loans, deposit webhook
server/db.js       SQLite schema + atomic transactions (money stored in kobo)
server/security.js password/PIN hashing (scrypt) and signed login tokens
server/loans.js    loan decision engine (score, limit, approve/review/decline)
server/providers.js payment-provider adapter (mock now; plug your real partner in here)
server/messenger.js sends reset codes and SMS alerts (prints to console now; plug in an SMS/email provider)
server/notify.js    alerts: in-app inbox + SMS for important events
server/interest.js + jobs.js savings interest: daily accrual, monthly payout
docs/GOING_LIVE.md step-by-step plan from sandbox to real money
```
**What is real:** accounts, login (lockout, rate limits), PIN-approved transfers with limits, idempotent retries,
automatic reversals, password reset by 6-digit code (signs you out everywhere), savings goals (₦2,000 minimum)
with interest accrued daily and paid monthly (8% / 10% / 12% a year by total saved), loan decisions + disbursement + repayment, tamper-proof ledger rows.
**Sandbox limitations:** external bank transfers, bill payments, deposits, identity checks, and message delivery use mock or console-only providers. Do not use this sandbox for real money or real customer information.

## New in this version
- **Savings withdrawals:** tap a goal, then Withdraw to wallet (PIN required).
- **Identity verification (Tier 3):** Profile, then Verify identity. Photos are shrunk on the phone, checked by file type on the server,
  stored outside `public/` under random names, and opened only by admins.
- **Admin dashboard:** http://localhost:3000/admin.html. To access it, first create a normal account in the app, then from the project folder run `npm run make-admin -- you@example.com` using that account's email. Sign in again at `/admin.html` with the same email and password. Admin decisions are written to the `admin_log` table; there is no public admin sign-up.
- **Noma Market with real orders:** listings, escrow (money held until the buyer confirms), shipping, disputes, 7-day auto-release
  after shipping, and Harvest Savings auto-save from each completed sale. Optional platform fee: set `MARKET_FEE_BPS` (100 = 1%).

## Order cancellation and alerts
- **Cancel an order:** before it ships, the buyer can cancel (Orders tab) or the seller can decline (Sell tab). The buyer is refunded in full and the stock goes back. After shipping, use Report a problem.
- **Alerts inbox:** the bell on the home screen shows unread alerts. Money received, orders, loan and ID decisions, dispute outcomes, interest payouts and security events all appear there.
- **SMS:** money, loan, ID, dispute and security alerts are also texted. Customers can switch SMS off in the inbox; security texts (password changed, PIN locked, account locked) always go out. Order updates stay in the app.
- **SMS in sandbox:** texts are printed in the server console. For real texts, implement `sendSms` in `server/messenger.js`.

## Installed app and push notifications
- The customer app is a Progressive Web App (PWA). Serve it over HTTPS (localhost is allowed for development), then install it from the browser: Chrome/Android uses **Install app**; iPhone/iPad uses Safari **Share → Add to Home Screen**.
- Push is opt-in per device from the app's **Notifications** inbox. The service worker displays generic lock-screen text only; account amounts, ID details and message bodies are kept inside the signed-in app.
- Push delivery requires the deployment environment variables `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY`, and `VAPID_SUBJECT`. Generate a matching public/private pair with `npx web-push generate-vapid-keys`; put the private key in the hosting provider's secrets store and never in source control. The app reports push as unavailable until valid keys are configured.
- Browser support and permission rules vary. On iOS/iPadOS, users must install the site to the Home Screen before allowing web push.

## Languages
- Arabic is localized across customer-facing app screens, common alerts and prompts, and switches the interface to right-to-left layout. The selected language is saved on the device.
- Hausa, Yorùbá, Igbo and Pidgin now cover every customer screen, alert and push notification, but are AI-written drafts. They must be reviewed by native speakers before launch: see `docs/TRANSLATION_REVIEW.md` and `docs/TRANSLATION_REVIEW.xlsx`. Server SMS texts are English only.

## Identity-check provider and text retries
- **BVN check:** talks to a real provider through settings only (`KYC_PROVIDER=http` plus a few variables). Sandbox mode uses test BVNs. Details in `docs/GOING_LIVE.md`.
- **Text retries:** failed texts retry automatically with growing waits, then show on the admin Overview with a Retry failed texts button.
- **NIN as an alternative to BVN:** customers with no BVN can verify with their NIN (same provider credentials, same safety rules). Details in `docs/GOING_LIVE.md`.
