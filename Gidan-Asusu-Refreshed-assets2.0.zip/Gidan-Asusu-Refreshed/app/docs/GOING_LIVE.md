# From sandbox to real money: step by step

1. **Run it locally.** `npm start`, create two accounts, use Add Money (sandbox), send money between them, apply for a loan.
2. **Get the right to hold customer money.** In Nigeria that is a CBN licence (e.g. microfinance bank) or a partnership with a
   licensed bank / Banking-as-a-Service provider that holds the funds and gives each customer a real account number. Talk to a
   fintech lawyer before onboarding real users. Lending also has its own rules (consumer protection, interest disclosure).
3. **Pick providers** (check each one's current docs and fees): a BaaS / virtual-account provider for customer account numbers and
   deposits, a payouts provider for bank transfers, a bills provider for airtime/electricity/data, and a KYC provider for BVN/NIN checks.
4. **Implement `server/providers.js`.** Fill the three functions (resolveAccount, transferToBank, payBill) with your partner's API,
   keep API keys in environment variables (never in `public/`), then set `PROVIDER`.
5. **Real deposits.** Point your provider's deposit webhook at `POST /api/webhooks/deposit`, set `WEBHOOK_SECRET`, and match the
   signature header/format your provider uses (edit the few lines in server.js). Replays are harmless: the reference is unique.
6. **Real KYC.** Replace the sandbox `POST /api/kyc` with a call to your KYC provider. Tier 1 has low limits; tier 2/3 raise them.
7. **Harden.** Set `NODE_ENV=production` (turns off sandbox funding/KYC), a long `JWT_SECRET`, HTTPS only (reverse proxy such as
   Caddy/Nginx), move SQLite to PostgreSQL, daily encrypted backups, and keep logs of every money movement.
7b. **Password reset delivery.** Implement `sendResetCode` in `server/messenger.js` with an SMS provider (e.g. Termii, Twilio) and/or email, then set `MESSENGER`. In production the server warns until this is done.
7c. **Interest job.** The server runs `runDue()` hourly and catches up after downtime. On more than one server, run `npm run jobs` from a single cron entry instead and set `JOBS=off` on the web servers. Interest is paid from your own funds: budget for it and show it in your accounting.
8. **Add what regulators and users expect:** password reset by email/SMS (needs a messaging provider), OTP for new devices,
   transaction alerts, interest payout job for savings rewards, dispute handling, an admin dashboard for loan reviews.
9. **Credit policy.** `server/loans.js` is a simple rules engine. Before lending real money, have a risk/credit professional set the
   policy, add credit-bureau data, collections, and default handling.
10. **Security review + pilot.** Get a penetration test, then pilot with a small group and small limits before opening up.
11. **Ship the mobile app.** Wrap `public/` (Capacitor) or rebuild screens in React Native/Flutter, calling the same `/api` routes.
    Store the token in the phone's secure storage.

## Before real customers use the new features
- **KYC files:** the `uploads/` folder holds ID photos. Encrypt the disk or the files, restrict who can read the server, back it up,
  and set a retention policy (Nigeria Data Protection Act). Consider a provider (Smile ID, Dojah) for automatic face matching.
- **Admins:** create only a few, use strong unique passwords, and add 2-step sign-in before going live. Review `admin_log` regularly.
- **Marketplace money:** the ESCROW account balance should always equal the value of orders still open. Check this daily.
- **Disputes:** write a clear policy (what proof counts, how long sellers have to respond) and show it in the app.

## Alerts in production
- **SMS provider:** implement `sendSms` (and `sendResetCode`) in `server/messenger.js`, then set `MESSENGER`. SMS costs money per message and Nigerian providers need a registered sender ID, so keep the texted events limited (see `SMS_KINDS` in `server/notify.js`).
- **Failed texts:** they are retried automatically (see "Text retries" below). Texts that still fail are counted on the admin Overview, with a Retry failed texts button.
- **Push notifications:** these need the native app. When you wrap or rebuild the app, add Firebase Cloud Messaging, store each phone's device token, and implement `sendPush` in `server/messenger.js`. The server already has the hook.
- **Message wording:** texts never include balances or PINs. Keep it that way, and have a lawyer review the wording of loan and dispute messages.

## Connecting a real identity-check (BVN) provider
The server already does the checking work around the provider: it asks for the customer's consent, sends the BVN, compares the name on the
BVN record with the account name (first and last name must both appear, any order, accents ignored), blocks a BVN already used by another
account (even when two requests arrive at the same moment), allows 3 unsuccessful checks a day, and keeps only the last 4 digits and a
one-way fingerprint of the BVN (never the number). A provider outage shows a "try again later" message and does not use up the customer's tries.

1. Open an account with a provider that offers BVN lookup (for example Dojah, Prembly, Smile ID) and read its current API docs. Each lookup costs money.
2. Set these environment variables (see `.env.example`). No code change is needed if the provider answers with JSON:
   - `KYC_PROVIDER=http`
   - `KYC_URL` the lookup address. For GET requests put `{bvn}` in it, e.g. `https://api.example.com/lookup/{bvn}`. For POST, give the address and set `KYC_METHOD=POST` and `KYC_BODY` (default `{"bvn":"{bvn}"}`).
   - `KYC_AUTH_VALUE` the secret, e.g. `Bearer sk_live_...`. `KYC_AUTH_HEADER` is the header name (default `Authorization`). `KYC_EXTRA_HEADERS` is optional JSON for headers like an app ID.
   - `KYC_MAP` tells the server where the details sit in the provider's answer, as JSON using dotted paths, e.g. `{"found":"entity.bvn","first":"entity.first_name","last":"entity.last_name","middle":"entity.middle_name","phone":"entity.phone_number"}`. `first` and `last` are required.
   - `KYC_TIMEOUT_MS` (default 8000).
3. Try it in the provider's sandbox with a test BVN before using a live key. If the provider's answer is unusual (for example a signed request), adjust `httpLookup` in `server/kyc-provider.js`.
4. Set `NODE_ENV=production`. While the sandbox provider is still selected, the server refuses BVN checks in production.
5. In sandbox mode, BVNs ending 0000 = not found, 1111 = belongs to someone else, 9999 = provider outage. Any other 11 digits match the customer.
6. Before launch, tell customers what is checked and why (Nigeria Data Protection Act), and agree a process for customers whose name legitimately differs from their BVN record (for example after marriage).
7. Not built: face matching the selfie against the ID or BVN photo, and liveness checks. Providers sell these, and they would replace the manual photo review.

## Text retries
- If the SMS provider fails, the text is retried after 1 minute, 5 minutes, 30 minutes and 2 hours (5 tries in all), then marked `failed`.
- Texts older than a day are dropped as stale. A text stuck "sending" after a crash is retried, so in rare cases a customer may get the same text twice.
- Failed texts appear on the admin Overview with a **Retry failed texts** button (only texts under a day old are re-queued).
- Reset codes are not retried: if the code does not arrive the customer taps Send a new code.

## NIN lookup (alternative to BVN)
Many customers, especially farmers, have a National Identification Number (NIN) but no BVN. A NIN check gives the same Tier 2 as a BVN check
and follows the same rules: consent, name must match, 3 unsuccessful tries a day (BVN and NIN share this limit), one number can verify only
one account (a NIN and a BVN with the same digits do not clash), and the number is never stored (only the last 4 digits and a one-way fingerprint).

It uses the **same provider credentials** as the BVN check. Only the address and field map differ:
- `KYC_NIN_URL` the NIN lookup address, with `{nin}` in it for GET requests (e.g. `https://api.example.com/nin/{nin}`). For POST set `KYC_NIN_METHOD=POST` and `KYC_NIN_BODY` (default `{"nin":"{nin}"}`).
- `KYC_NIN_MAP` the same kind of dotted-path map as `KYC_MAP`, pointing at the names in the NIN answer, e.g. `{"found":"data.nin","first":"data.firstname","last":"data.surname","middle":"data.middlename","phone":"data.telephoneno"}`.
- Shared with BVN: `KYC_PROVIDER=http`, `KYC_AUTH_VALUE`, `KYC_AUTH_HEADER`, `KYC_EXTRA_HEADERS`, `KYC_TIMEOUT_MS`. `KYC_NIN_METHOD` falls back to `KYC_METHOD`.
- **The NIN option appears in the app only when `KYC_NIN_URL` and `KYC_NIN_MAP` are set.** Until then customers see BVN only, and the server answers NIN requests with "not available yet".
- In the sandbox, test numbers behave as for BVN: ending 0000 = not found, 1111 = someone else's, 9999 = provider outage.
- Check your provider's price list: NIN lookups are often priced differently from BVN lookups. Many providers use a different address and field names for NIN, so always test with the provider's sandbox first.

## Hosting behind a proxy
Sign-in, sign-up and reset requests are limited to 20 a minute per address (`AUTH_RATE_LIMIT` changes this). Behind a proxy such as Nginx or a hosting platform,
every customer looks like one address unless you set `TRUST_PROXY=1` **and** your proxy sets the `X-Forwarded-For` header itself. Do not set `TRUST_PROXY` when the server is reachable directly from the internet, because then anyone could fake that header.
