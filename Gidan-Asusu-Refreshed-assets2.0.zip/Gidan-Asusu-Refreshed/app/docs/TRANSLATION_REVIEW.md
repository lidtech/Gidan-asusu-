# Translation status and review

| Language | Code | Coverage | Status |
|---|---|---|---|
| English | `en` | source | n/a |
| Arabic | `ar` | full (RTL) | existing; not re-reviewed here |
| Hausa | `ha` | full (356 strings + 43 message templates) | **draft, awaiting native-speaker sign-off** |
| Yorùbá | `yo` | full | **draft, awaiting native-speaker sign-off** |
| Igbo | `ig` | full | **draft, awaiting native-speaker sign-off** |
| Naijá Pidgin | `pcm` | full | **draft, awaiting native-speaker sign-off** |

The drafts were written by an AI assistant. No native speaker has reviewed them. Do not ship them to customers until each language is signed off.

## Review process
1. Give `docs/TRANSLATION_REVIEW.xlsx` to one native reviewer per language (one tab each). Money, security, loan and identity wording is marked `High` priority; have compliance check those too.
2. Apply corrections to `public/js/core/lang-<code>.js` (`d` = exact strings, `p` = message templates; `$1`, `$2` are the inserted names/amounts).
3. Run `npm test`. It checks every pack is complete and that amounts, names and codes survive the templates.
4. When a language is signed off, change its status here and remove the DRAFT comment at the top of its file.

## How it works
- `i18n.js` looks up the English text exactly (`d`), then tries the shared regexes in `TRX` (`p` templates are index-aligned with `TRX`), then localizes dates and the `· score N/100` suffix.
- Customer names, listings and free text are never translated (exact matching only).
- Push notification titles and bodies are localized in `server/notify.js`. **SMS texts from the server are still English only.**
- To add a string: add the English text to each pack's `d`. To add a dynamic message: add a regex to `TRX` and a template to every pack (the test fails if the counts differ).
