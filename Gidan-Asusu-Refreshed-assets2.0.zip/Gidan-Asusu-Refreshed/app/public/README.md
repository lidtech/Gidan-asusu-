# Gidan asusu - mobile banking prototype
Plain HTML/CSS/JS, no build step. Open `index.html` in a browser (phone-sized view works best).

```
index.html            page shell + logo/Arewa pattern defs
css/style.css         all styles and color tokens
assets/logo.svg       standalone logo
js/core/              state, i18n (languages), utils, components, router
js/screens/           one file per feature (auth, home, transfer, cards, savings,
                      bills, loans, history, language, account, farm, market, harvest)
js/main.js            starts the app
```
Scripts load in order (see index.html); they share globals, so keep that order.
Data is in-memory demo data. A real app needs a backend for auth, accounts, payments, loans and escrow.
