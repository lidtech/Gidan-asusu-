// Operations console for loan reviews, identity checks, and marketplace disputes.
// Customer-provided values are always rendered as text, never as HTML.
const root = document.getElementById('root');
let tab = 'Overview';
let tk = sessionStorage.getItem('atk') || '';
let activeDialog = null;
let toastTimer = null;
const fileUrls = new Set();

const icon = (name) => {
  const paths = {
    Overview: [['rect', { x: 3, y: 3, width: 7, height: 7, rx: 1.5 }], ['rect', { x: 14, y: 3, width: 7, height: 7, rx: 1.5 }], ['rect', { x: 3, y: 14, width: 7, height: 7, rx: 1.5 }], ['rect', { x: 14, y: 14, width: 7, height: 7, rx: 1.5 }]],
    Loans: [['path', { d: 'M4 7.5h16M6 4h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z' }], ['path', { d: 'M8 12h8M8 16h5' }]],
    KYC: [['path', { d: 'M12 3 19 6v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3Z' }], ['path', { d: 'm9 12 2 2 4-4' }]],
    Disputes: [['path', { d: 'M5 5h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-8l-5 3v-3a2 2 0 0 1-3-2V7a2 2 0 0 1 2-2Z' }], ['path', { d: 'M8 10h8M8 14h5' }]],
    Shield: [['path', { d: 'M12 3 19 6v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3Z' }], ['path', { d: 'M9 12h6' }]],
    Refresh: [['path', { d: 'M20 7v5h-5M4 17v-5h5' }], ['path', { d: 'M5.6 9A7 7 0 0 1 18 6l2 2M4 16l2 2a7 7 0 0 0 12.4-3' }]]
  };
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  (paths[name] || paths.Overview).forEach(([tag, attributes]) => {
    const shape = document.createElementNS('http://www.w3.org/2000/svg', tag);
    Object.entries(attributes).forEach(([key, value]) => shape.setAttribute(key, String(value)));
    svg.append(shape);
  });
  return svg;
};
const el = (tag, attrs = {}, ...children) => {
  const node = document.createElement(tag);
  Object.entries(attrs).forEach(([key, value]) => {
    if (key === 'onclick') node.addEventListener('click', value);
    else if (key === 'oninput') node.addEventListener('input', value);
    else if (key === 'onsubmit') node.addEventListener('submit', value);
    else if (key === 'onkeydown') node.addEventListener('keydown', value);
    else if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key === 'disabled') node.disabled = Boolean(value);
    else if (key === 'checked') node.checked = Boolean(value);
    else if (value !== undefined && value !== null) node.setAttribute(key, value);
  });
  children.flat(Infinity).forEach(child => {
    if (child === null || child === undefined || child === false) return;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  });
  return node;
};
const N = value => '₦' + Number(value || 0).toLocaleString('en-NG');
const when = value => {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? 'Date unavailable' : date.toLocaleString('en-NG', { dateStyle: 'medium', timeStyle: 'short' });
};
const api = async (path, body) => {
  const response = await fetch('/gidan-api' + path, {
    method: body !== undefined ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tk },
    body: body !== undefined ? JSON.stringify(body) : undefined
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401) signOut();
    throw new Error(data.error || 'Something went wrong. Please try again.');
  }
  return data;
};
const closeDialog = () => {
  if (activeDialog?.open) activeDialog.close();
  activeDialog?.remove();
  activeDialog = null;
};
const clearFileUrls = () => {
  fileUrls.forEach(url => URL.revokeObjectURL(url));
  fileUrls.clear();
};
const signOut = () => {
  closeDialog();
  clearFileUrls();
  sessionStorage.removeItem('atk');
  tk = '';
  show();
};
const notify = message => {
  document.querySelector('.toast')?.remove();
  clearTimeout(toastTimer);
  const toast = el('div', { class: 'toast', role: 'status', 'aria-live': 'polite' }, message);
  document.body.append(toast);
  toastTimer = setTimeout(() => toast.remove(), 3600);
};
const brand = () => {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 60 56');
  svg.setAttribute('aria-hidden', 'true');
  [
    ['M30 3 4 24v6l26-20 26 20v-6L30 3Z', '#19a66d'],
    ['M12 28v24h36V28L30 15 12 28Z', '#08734f'],
    ['M22 52V34h16v18', '#fff']
  ].forEach(([d, fill]) => {
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('d', d);
    path.setAttribute('fill', fill);
    svg.append(path);
  });
  const detail = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  detail.setAttribute('d', 'm30 34-8 8m8-8 8 8m-8-8v18');
  detail.setAttribute('stroke', '#d9b92e');
  detail.setAttribute('stroke-width', '1.4');
  detail.setAttribute('fill', 'none');
  svg.append(detail);
  const mark = el('span', { class: 'brand-mark', 'aria-hidden': 'true' }, svg);
  return el('div', { class: 'brand' }, mark,
    el('span', { class: 'brand-copy' },
      el('span', { class: 'brand-name' }, 'Gidan asusu'),
      el('span', { class: 'brand-sub' }, 'Community banking')
    )
  );
};
const login = () => {
  const status = el('p', { class: 'login-status', role: 'status', 'aria-live': 'polite' });
  const id = el('input', { id: 'admin-email', name: 'id', type: 'email', autocomplete: 'username', required: '', placeholder: 'you@example.com' });
  const password = el('input', { id: 'admin-password', name: 'password', type: 'password', autocomplete: 'current-password', required: '', placeholder: 'Enter your password' });
  const submit = el('button', { class: 'btn', type: 'submit' }, 'Sign in securely');
  const form = el('form', { onsubmit: async event => {
    event.preventDefault();
    submit.disabled = true;
    submit.textContent = 'Signing in…';
    status.textContent = '';
    try {
      const response = await fetch('/gidan-api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: id.value.trim(), password: password.value })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'Sign in failed. Check your details and try again.');
      tk = data.token;
      const me = await api('/me');
      if (me.user?.role !== 'admin') {
        tk = '';
        throw new Error('This account is not an admin.');
      }
      sessionStorage.setItem('atk', tk);
      tab = 'Overview';
      await show();
    } catch (error) {
      status.textContent = error.message || 'Unable to sign in.';
      submit.disabled = false;
      submit.textContent = 'Sign in securely';
      password.value = '';
      password.focus();
    }
  } },
  el('label', { class: 'field', for: 'admin-email' }, el('span', {}, 'Admin email'), id),
  el('label', { class: 'field', for: 'admin-password' }, el('span', {}, 'Password'), password),
  submit, status);
  return el('main', { class: 'login-wrap' },
    el('section', { class: 'login-card', 'aria-labelledby': 'login-title' },
      brand(),
      el('p', { class: 'eyebrow' }, 'Staff access'),
      el('h1', { id: 'login-title' }, 'Operations sign in'),
      el('p', { class: 'login-help' }, 'Sign in with your authorized staff account to review customer activity.'),
      form,
      el('div', { class: 'login-foot' }, el('span', { class: 'secure-label' }, el('i', { class: 'secure-dot', 'aria-hidden': 'true' }), 'Protected staff workspace'))
    )
  );
};
const pageCopy = {
  Overview: ['Your operations at a glance', 'A clear view of reviews and activity across the community.'],
  Loans: ['Loan reviews', 'Review each application before making a lending decision.'],
  KYC: ['Identity checks', 'Review customer documents and identity verification requests.'],
  Disputes: ['Marketplace disputes', 'Resolve held marketplace payments with a recorded outcome.']
};
const makeHeader = () => el('header', { class: 'topbar' },
  brand(),
  el('span', { class: 'secure-label' }, el('i', { class: 'secure-dot', 'aria-hidden': 'true' }), 'Authorized staff workspace'),
  el('button', { class: 'signout', type: 'button', onclick: signOut }, 'Sign out')
);
const makeTabs = () => el('nav', { class: 'sidebar', 'aria-label': 'Admin sections' },
  el('div', { class: 'side-caption' }, 'Workspace'),
  el('div', { class: 'tabs', role: 'tablist', 'aria-label': 'Operations sections' },
    ...Object.keys(views).map((name, index) => {
      const button = el('button', {
        class: 'tab' + (name === tab ? ' on' : ''),
        type: 'button',
        role: 'tab',
        id: 'tab-' + name.toLowerCase(),
        'aria-selected': String(name === tab),
        'aria-controls': 'panel-main',
        tabindex: name === tab ? '0' : '-1',
        onclick: () => { tab = name; show(); },
        onkeydown: event => {
          if (!['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(event.key)) return;
          event.preventDefault();
          const names = Object.keys(views);
          const next = event.key === 'Home' ? 0 : event.key === 'End' ? names.length - 1 :
            (index + (event.key === 'ArrowRight' ? 1 : -1) + names.length) % names.length;
          tab = names[next];
          show().then(() => document.getElementById('tab-' + tab.toLowerCase())?.focus());
        }
      }, el('span', { class: 'tab-icon' }, icon(name)), el('span', {}, name));
      return button;
    })
  ),
  el('div', { class: 'sidebar-note' }, el('strong', {}, 'Handle with care'), 'Customer identity and financial details are visible only to authorized staff.')
);
const makePageHeading = () => {
  const [title, description] = pageCopy[tab];
  return el('div', { class: 'page-heading' },
    el('div', {}, el('p', { class: 'eyebrow' }, 'Operations console'), el('h1', {}, title), el('p', { class: 'page-description' }, description)),
    el('span', { class: 'refresh-mark' }, icon('Shield'), 'Private staff view')
  );
};
const metric = (label, value) => el('article', { class: 'metric' },
  el('i', { class: 'metric-mark', 'aria-hidden': 'true' }),
  el('div', { class: 'metric-label' }, label),
  el('strong', { class: 'metric-value' }, String(value))
);
const sectionHeading = (title, helper) => el('div', { class: 'section-title' }, el('h2', {}, title), el('span', {}, helper));
const emptyState = message => el('div', { class: 'empty-state' }, el('strong', {}, 'All caught up'), el('p', {}, message));
const errorState = (error, retry) => el('div', { class: 'error-state', role: 'alert' },
  el('strong', {}, 'We could not load this section'),
  el('p', {}, error.message || 'Please try again in a moment.'),
  el('div', { class: 'actions', style: 'justify-content:center' }, el('button', { class: 'btn secondary', type: 'button', onclick: retry }, 'Try again'))
);
const loadingState = () => el('div', { class: 'loading-state', role: 'status', 'aria-label': 'Loading section' },
  el('div', { class: 'skeleton' }), el('div', { class: 'skeleton', style: 'max-width:160px' }), el('p', {}, 'Loading secure records…')
);
const actionButton = (label, className, action) => el('button', { class: 'btn' + (className ? ' ' + className : ''), type: 'button', onclick: action }, label);
const decisionDialog = ({ title, description, label = 'Audit note', required = false, submitLabel, danger = false, onConfirm }) => {
  closeDialog();
  const note = el('textarea', { rows: '3', maxlength: '1000', placeholder: required ? 'Enter at least 3 characters' : 'Optional context for the audit log' });
  const message = el('p', { class: 'login-status', role: 'alert' });
  const dialog = el('dialog', { 'aria-labelledby': 'dialog-title' });
  const cancel = actionButton('Cancel', 'secondary', closeDialog);
  const confirm = actionButton(submitLabel, danger ? 'danger' : '', async () => {
    const text = note.value.trim();
    if (required && text.length < 3) {
      message.textContent = 'Please provide a reason of at least 3 characters.';
      note.focus();
      return;
    }
    confirm.disabled = true;
    confirm.textContent = 'Submitting…';
    cancel.disabled = true;
    try {
      await onConfirm(text);
      closeDialog();
      await show();
      notify('Decision recorded successfully.');
    } catch (error) {
      message.textContent = error.message || 'The decision could not be recorded.';
      confirm.disabled = false;
      confirm.textContent = submitLabel;
      cancel.disabled = false;
    }
  });
  const form = el('form', { onsubmit: event => { event.preventDefault(); confirm.click(); } },
    el('label', { class: 'field' }, el('span', {}, label, required ? ' (required)' : ' (optional)'), note),
    message,
    el('div', { class: 'dialog-actions' }, cancel, confirm)
  );
  dialog.append(el('div', { class: 'dialog-inner' },
    el('h2', { id: 'dialog-title' }, title),
    el('p', {}, description),
    form
  ));
  dialog.addEventListener('click', event => {
    if (event.target === dialog) closeDialog();
  });
  dialog.addEventListener('close', () => {
    dialog.remove();
    if (activeDialog === dialog) activeDialog = null;
  });
  activeDialog = dialog;
  document.body.append(dialog);
  dialog.showModal();
  note.focus();
};
const listWrap = (...items) => el('div', { class: 'record-list' }, ...items);
const act = async (path, body) => api(path, body);

const views = {
  async Overview() {
    const stats = await api('/admin/stats');
    const tiles = [
      ['Customers', stats.users],
      ['Customer wallets', N(stats.wallets)],
      ['Held in marketplace escrow', N(stats.escrow)],
      ['Loans outstanding', N(stats.loansOut)],
      ['Loans to review', stats.loanReviews],
      ['Identity checks to review', stats.kycPending],
      ['Open disputes', stats.disputes],
      ['Texts that failed', stats.smsFailed]
    ];
    const content = el('div', {},
      sectionHeading('Community activity', 'Current platform totals'),
      el('div', { class: 'metric-grid' }, ...tiles.map(([label, value]) => metric(label, value))),
      sectionHeading('Delivery health', 'Account notifications'),
      el('div', { class: 'signal-card' },
        el('div', { class: 'signal-copy' }, el('strong', {}, 'Failed text messages'), el('p', {}, 'Retry delivery for messages that did not reach customers.')),
        el('div', { class: 'signal-value', 'aria-label': String(stats.smsFailed) + ' failed texts' }, String(stats.smsFailed))
      )
    );
    if (Number(stats.smsFailed) > 0) {
      content.lastChild.append(actionButton('Retry failed texts', 'secondary', async event => {
        event.currentTarget.disabled = true;
        try {
          await act('/admin/sms/retry', {});
          notify('Text retry request sent.');
          await show();
        } catch (error) {
          notify(error.message);
          event.currentTarget.disabled = false;
        }
      }));
    }
    return content;
  },
  async Loans() {
    const data = await api('/admin/loans');
    const rows = Array.isArray(data.items) ? data.items : [];
    return rows.length ? listWrap(...rows.map(loan => {
      const reasons = Array.isArray(loan.reasons) ? loan.reasons.filter(Boolean).join('. ') : '';
      return el('article', { class: 'record' },
        el('div', { class: 'record-top' },
          el('div', {}, el('h2', { class: 'record-title' }, loan.name || 'Customer'), el('p', { class: 'record-subtitle' }, [loan.email, loan.phone].filter(Boolean).join(' · '))),
          el('span', { class: 'pill warn' }, 'Score ' + String(loan.score ?? '—') + '/100')
        ),
        el('p', { class: 'record-detail' }, N(loan.amount) + ' requested for ' + String(loan.months || '—') + ' months'),
        el('p', { class: 'record-meta' }, 'Tier ' + String(loan.tier || '—') + ' · Total to repay ' + N(loan.total) + ' · Applied ' + when(loan.created_at)),
        el('p', { class: 'record-meta' }, reasons || 'No additional application notes.'),
        el('div', { class: 'actions' },
          actionButton('Approve and pay out', '', () => decisionDialog({
            title: 'Approve loan application',
            description: 'Confirm the lending decision for ' + (loan.name || 'this customer') + '.',
            submitLabel: 'Approve application',
            onConfirm: note => act('/admin/loans/' + encodeURIComponent(loan.id) + '/decide', { decision: 'approve', note })
          })),
          actionButton('Decline', 'danger', () => decisionDialog({
            title: 'Decline loan application',
            description: 'Give the customer a clear reason for this decision.',
            required: true,
            submitLabel: 'Decline application',
            danger: true,
            onConfirm: note => act('/admin/loans/' + encodeURIComponent(loan.id) + '/decide', { decision: 'decline', note })
          }))
        )
      );
    })) : emptyState('There are no loan applications waiting for review.');
  },
  async KYC() {
    const data = await api('/admin/kyc');
    const rows = Array.isArray(data.items) ? data.items : [];
    return rows.length ? listWrap(...rows.map(customer => {
      const documents = el('div', { class: 'document-view', 'aria-live': 'polite' });
      const documentButtons = (Array.isArray(customer.docs) ? customer.docs : []).map(doc =>
        actionButton('View ' + (doc.type || 'document'), 'secondary', async event => {
          const button = event.currentTarget;
          button.disabled = true;
          button.textContent = 'Opening…';
          try {
            const response = await fetch('/gidan-api/admin/kyc/file/' + encodeURIComponent(doc.id), {
              headers: { Authorization: 'Bearer ' + tk }
            });
            if (!response.ok) {
              if (response.status === 401) signOut();
              throw new Error('Could not open this document. Please try again.');
            }
            const url = URL.createObjectURL(await response.blob());
            fileUrls.add(url);
            const view = doc.mime === 'application/pdf'
              ? el('a', { class: 'document-link', href: url, target: '_blank', rel: 'noopener noreferrer' }, 'Open PDF in new tab')
              : el('img', { src: url, alt: (doc.type || 'Identity document') + ' preview' });
            documents.replaceChildren(view);
            button.textContent = 'View ' + (doc.type || 'document');
          } catch (error) {
            documents.replaceChildren(el('span', { class: 'record-meta', role: 'alert' }, error.message));
            button.textContent = 'Try ' + (doc.type || 'document') + ' again';
          } finally {
            button.disabled = false;
          }
        })
      );
      return el('article', { class: 'record' },
        el('div', { class: 'record-top' },
          el('div', {}, el('h2', { class: 'record-title' }, customer.name || 'Customer'), el('p', { class: 'record-subtitle' }, [customer.email, customer.phone].filter(Boolean).join(' · '))),
          el('span', { class: 'pill' }, 'Tier ' + String(customer.kyc_tier || 'Pending'))
        ),
        el('div', { class: 'actions' }, documentButtons.length ? documentButtons : el('span', { class: 'record-meta' }, 'No documents attached.')),
        documents,
        el('div', { class: 'actions' },
          actionButton('Approve · Tier 3', '', () => decisionDialog({
            title: 'Approve identity check',
            description: 'Confirm that the submitted identity documents have been reviewed.',
            submitLabel: 'Approve identity',
            onConfirm: note => act('/admin/kyc/' + encodeURIComponent(customer.id) + '/decide', { decision: 'approve', note })
          })),
          actionButton('Reject', 'danger', () => decisionDialog({
            title: 'Reject identity check',
            description: 'Provide a reason so the customer knows what needs attention.',
            required: true,
            submitLabel: 'Reject identity',
            danger: true,
            onConfirm: note => act('/admin/kyc/' + encodeURIComponent(customer.id) + '/decide', { decision: 'reject', note })
          }))
        )
      );
    })) : emptyState('There are no identity checks waiting for review.');
  },
  async Disputes() {
    const data = await api('/admin/disputes');
    const rows = Array.isArray(data.items) ? data.items : [];
    return rows.length ? listWrap(...rows.map(dispute =>
      el('article', { class: 'record' },
        el('div', { class: 'record-top' },
          el('div', {}, el('h2', { class: 'record-title' }, (dispute.item || 'Marketplace item') + ' · ' + N(dispute.amount)), el('p', { class: 'record-subtitle' }, 'Reference ' + String(dispute.ref || '—') + ' · Quantity ' + String(dispute.qty || '—'))),
          el('span', { class: 'pill warn' }, 'Open dispute')
        ),
        el('p', { class: 'record-detail' }, 'Buyer ' + String(dispute.buyer || '—') + ' · Seller ' + String(dispute.seller || '—')),
        el('p', { class: 'record-detail' }, 'Buyer says: ' + String(dispute.reason || 'No reason provided.')),
        el('p', { class: 'record-meta' }, 'Opened ' + when(dispute.created_at)),
        el('div', { class: 'actions' },
          actionButton('Refund buyer', 'danger', () => decisionDialog({
            title: 'Refund the buyer',
            description: 'Record the outcome and return the held payment to the buyer.',
            submitLabel: 'Confirm refund',
            onConfirm: note => act('/admin/disputes/' + encodeURIComponent(dispute.id) + '/resolve', { outcome: 'refund', note })
          })),
          actionButton('Release payment to seller', 'secondary', () => decisionDialog({
            title: 'Release payment to seller',
            description: 'Record the outcome and release the held payment to the seller.',
            submitLabel: 'Release payment',
            onConfirm: note => act('/admin/disputes/' + encodeURIComponent(dispute.id) + '/resolve', { outcome: 'release', note })
          }))
        )
      )
    )) : emptyState('There are no open marketplace disputes.');
  }
};

async function show() {
  closeDialog();
  clearFileUrls();
  root.replaceChildren();
  if (!tk) {
    root.append(login());
    document.getElementById('admin-email')?.focus();
    return;
  }
  const shell = el('div', { class: 'app-shell' }, makeHeader());
  const contentPanel = el('section', { class: 'content', id: 'panel-main', role: 'tabpanel', 'aria-labelledby': 'tab-' + tab.toLowerCase() },
    makePageHeading(), loadingState()
  );
  const layout = el('main', { class: 'layout' }, makeTabs(), contentPanel);
  shell.append(layout);
  root.append(shell);
  try {
    const content = await views[tab]();
    if (!tk) return;
    contentPanel.replaceChildren(makePageHeading(), content);
  } catch (error) {
    if (!tk) return;
    contentPanel.replaceChildren(makePageHeading(), errorState(error, show));
  }
}

show();
