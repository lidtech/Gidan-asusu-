const CACHE='gidan-shell-v3';
const SHELL=[
  '/',
  '/manifest.webmanifest',
  '/assets/app-icon.svg',
  '/assets/app-icon-192.png',
  '/assets/app-icon-512.png',
  '/css/style.css',
  '/js/core/state.js',
  '/js/core/lang-ha.js',
  '/js/core/lang-yo.js',
  '/js/core/lang-ig.js',
  '/js/core/lang-pcm.js',
  '/js/core/i18n.js',
  '/js/core/utils.js',
  '/js/core/avatars.js',
  '/js/core/components.js',
  '/js/core/ui.js',
  '/js/core/api.js',
  '/js/push.js',
  '/js/screens/auth.js',
  '/js/screens/home.js',
  '/js/screens/transfer.js',
  '/js/screens/cards.js',
  '/js/screens/savings.js',
  '/js/screens/bills.js',
  '/js/screens/loans.js',
  '/js/screens/history.js',
  '/js/screens/language.js',
  '/js/screens/account.js',
  '/js/screens/kyc.js',
  '/js/screens/farm.js',
  '/js/screens/market.js',
  '/js/screens/harvest.js',
  '/js/screens/inbox.js',
  '/js/core/router.js',
  '/js/main.js'
];

self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  const req=event.request,url=new URL(req.url);
  if(req.method!=='GET'||url.origin!==self.location.origin||url.pathname.startsWith('/api/')||url.pathname.startsWith('/gidan-api/'))return;
  event.respondWith(fetch(req).then(response=>{
    if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(req,copy))}
    return response;
  }).catch(()=>caches.match(req).then(cached=>cached||caches.match('/'))));
});
self.addEventListener('push',event=>{
  let data={};try{data=event.data?event.data.json():{}}catch{}
  event.waitUntil(self.registration.showNotification(data.title||'Gidan asusu',{
    body:data.body||'Open the app to view details.',
    icon:'/assets/app-icon.svg',
    badge:'/assets/app-icon.svg',
    tag:data.tag||'gidan-alert',
    data:{url:data.url||'/'}
  }));
});
self.addEventListener('notificationclick',event=>{
  event.notification.close();
  const target=new URL(event.notification.data?.url||'/',self.location.origin).href;
  event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(list=>{
    const existing=list.find(client=>new URL(client.url).origin===self.location.origin);
    if(existing){existing.focus();if('navigate'in existing)existing.navigate(target);return}
    return self.clients.openWindow(target);
  }));
});
