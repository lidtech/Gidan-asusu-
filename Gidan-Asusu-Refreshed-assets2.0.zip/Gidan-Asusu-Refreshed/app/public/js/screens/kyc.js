// Identity verification (Tier 3): upload a government ID and a selfie; an admin reviews them.
let kyc={docs:[],stale:true};
const loadKyc=async()=>{kyc.stale=false;try{kyc.docs=(await api('/kyc')).docs}catch(e){}if(A.dataset.s=='kyc')go('kyc')};
S.kyc=()=>{if(kyc.stale)loadKyc();
  const st=k=>{const d=kyc.docs.filter(x=>x.type==k).pop();return d?`<span class="pill">${d.status}</span>${d.status=='rejected'&&d.note?`<div class="mu">Reason: ${esc(d.note)}</div>`:''}`:''};
  if(user.tier<2)return `<div class="scr">${topBar('Verify identity','prof')}<p class="mu">Verify your BVN or NIN first, then come back here.</p><div class="btn" onclick="verifyBvn()">Verify BVN or NIN</div></div>`;
  if(user.kycStatus=='approved')return `<div class="scr">${topBar('Verify identity','prof')}<div class="ok">✓</div><h1 style="text-align:center">You are fully verified</h1></div>`;
  return `<div class="scr">${topBar('Verify identity','prof')}<p class="mu">${user.kycStatus=='pending'?'Your documents are in review. We will update you within 24 hours.':'Verified accounts get the highest limits. Your documents are only used to confirm who you are.'}</p>
  <h2 style="margin-top:12px">Government ID (NIN slip, voter's card, licence or passport) ${st('id')}</h2><input class="in" id="k_id" type="file" accept="image/*,.pdf">
  <h2 style="margin-top:12px">Selfie holding your ID ${st('selfie')}</h2><input class="in" id="k_self" type="file" accept="image/*" capture="user">
  <div class="btn" onclick="submitKyc()">Submit for review</div></div>`};
// Photos are shrunk in the browser first so phone pictures fit under the 1 MB limit.
const fileB64=f=>new Promise((res,rej)=>{if(!f)return rej(new Error('Choose both files first'));
  if(!f.type.startsWith('image/')){if(f.size>9e5)return rej(new Error('PDF must be under 1 MB'));const r=new FileReader();r.onload=()=>res(r.result.split(',')[1]);return r.readAsDataURL(f)}
  const img=new Image();img.onload=()=>{const s=Math.min(1,1280/Math.max(img.width,img.height)),c=document.createElement('canvas');c.width=Math.round(img.width*s);c.height=Math.round(img.height*s);c.getContext('2d').drawImage(img,0,0,c.width,c.height);res(c.toDataURL('image/jpeg',.75).split(',')[1])};img.onerror=()=>rej(new Error('Could not read that image'));img.src=URL.createObjectURL(f)});
const submitKyc=async()=>{try{const id=await fileB64(document.getElementById('k_id').files[0]),sf=await fileB64(document.getElementById('k_self').files[0]);
  await api('/kyc/documents',{body:{type:'id',data:id}});await api('/kyc/documents',{body:{type:'selfie',data:sf}});kyc.stale=true;await refresh();go('kyc');toast('Submitted. We will review within 24 hours.')}catch(e){toast(e.message)}};
