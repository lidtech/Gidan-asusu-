// Harvest Savings: a share of every completed Noma Market sale is saved automatically (server: /api/harvest).
S.harvest=()=>{const g=goals.find(x=>x[0]=='Harvest Savings'),p=user.harvestPct||0;
  return `<div class="scr">${topBar('Harvest Savings','farm')}<div class="card gc"><span style="font-size:12px">Harvest savings balance</span><h1>${N(g?g[1]:0)}</h1><span style="font-size:12px">Earning ${sv.ratePct}% a year like all savings</span></div>
  <div class="card"><b>Auto-save from sales</b><p class="mu">When a sale completes, this share goes straight into Harvest Savings and the rest to your wallet.</p></div>
  <h2 style="margin-top:14px">Share of each sale</h2><div class="row" style="margin-top:8px;flex-wrap:wrap">${[0,5,10,20,30].map(x=>`<span class="pill" style="cursor:pointer;${x==p?'background:var(--g1);color:#fff':''}" onclick="setHarvest(${x})">${x?x+'%':'Off'}</span>`).join('')}</div>
  <p class="mu" style="margin-top:12px">Example: a ₦48,000 sale saves ${N(48000*p/100)} and sends ${N(48000-48000*p/100)} to your wallet.</p></div>${nav()}`};
const setHarvest=async p=>{try{await api('/harvest',{body:{pct:p}});user.harvestPct=p;go('harvest');toast(p?p+'% of each sale will be saved':'Auto-save turned off')}catch(e){toast(e.message)}};
