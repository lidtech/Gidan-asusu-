// Language selector (re-renders with the chosen language).
S.lang=()=>`<div class="scr">${topBar(t('lang'),'more')}<p class="mu">${t('choose')}</p><div style="margin-top:8px">${Object.keys(LN).map(k=>`<div class="lg ${k==lg?'on':''}" onclick="setLanguage('${k}')"><span>${LN[k]}</span><span>${k==lg?glyph('check'):''}</span></div>`).join('')}</div></div>${nav()}`;
