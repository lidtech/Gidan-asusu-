// Transaction history.
S.hist=()=>`<div class="scr">${topBar(t('hist'))}${txs(3)}${txs(2)}</div>${nav()}`;
