// Entry point: resume the session if a token exists, otherwise show the splash.
if(sessionStorage.getItem('tk'))refresh().then(()=>go('home')).catch(()=>go('splash'));else go('splash');
// Check for new alerts every minute while signed in and update the bell on the home screen.
setInterval(()=>{if(sessionStorage.getItem('tk'))api('/notifications').then(n=>{const changed=n.unread!==nt.unread;nt=n;if(changed&&A.dataset.s=='home')go('home')}).catch(()=>{})},60000);
