// Installed-web-app push controls. The server sends generic lock-screen copy only.
let pushState={status:'loading',subscription:null,config:null};
if(typeof navigator!=='undefined'&&'serviceWorker'in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});

const pushCard=()=>`<div class="card push-card"><div class="row sp"><div><b>${localizeText('Push notifications')}</b><div class="mu push-status">${localizeText(pushState.status==='on'?'Push notifications are on for this device.':pushState.status==='off'?'Push notifications are off for this device.':pushState.status==='unsupported'?'Push is not supported in this browser.':pushState.status==='permission'?'Allow notifications in your browser settings, then try again.':pushState.status==='unconfigured'?'Push delivery is not configured yet. The app administrator must add VAPID keys.':'Get secure alerts on this installed app, even when it is closed.')}</div></div></div>${['on','off'].includes(pushState.status)?`<button class="btn ${pushState.status==='on'?'o':''}" type="button" onclick="togglePush()">${localizeText(pushState.status==='on'?'Disable push notifications':'Enable push notifications')}</button>`:''}</div>`;

const loadPushStatus=async()=>{
  pushState={status:'loading',subscription:null,config:null};
  try{
    const config=await api('/push/config');pushState.config=config;
    if(!config.enabled){pushState.status='unconfigured';}
    else if(typeof navigator==='undefined'||!navigator.serviceWorker||typeof window==='undefined'||!('PushManager'in window)||!('Notification'in window)){pushState.status='unsupported';}
    else if(Notification.permission==='denied'){pushState.status='permission';}
    else{
      const registration=await navigator.serviceWorker.register('/sw.js');
      pushState.subscription=await registration.pushManager.getSubscription();
      pushState.status=pushState.subscription?'on':'off';
    }
  }catch{pushState.status='unsupported'}
  if(typeof A!=='undefined'&&A.dataset.s==='inbox')go('inbox');
};

const pushKeyBytes=value=>{
  const normalized=String(value||'').replace(/-/g,'+').replace(/_/g,'/');
  const raw=atob(normalized+'='.repeat((4-normalized.length%4)%4));
  return Uint8Array.from(raw,c=>c.charCodeAt(0));
};
const syncPushLocale=()=>{if(pushState.subscription&&sessionStorage.getItem('tk'))api('/push/subscriptions',{body:{...pushState.subscription.toJSON(),locale:lg}}).catch(()=>{})};
const togglePush=async()=>{
  try{
    if(pushState.status==='on'&&pushState.subscription){
      await api('/push/unsubscribe',{body:{endpoint:pushState.subscription.endpoint}});
      await pushState.subscription.unsubscribe();
      pushState.subscription=null;pushState.status='off';toast(localizeText('Notifications disabled on this device'));
    }else{
      if(!pushState.config?.enabled||!pushState.config.publicKey)throw new Error('Push delivery is not configured yet. The app administrator must add VAPID keys.');
      if(Notification.permission==='denied'){pushState.status='permission';go('inbox');return}
      const permission=await Notification.requestPermission();
      if(permission!=='granted'){pushState.status=permission==='denied'?'permission':'off';go('inbox');return}
      const registration=await navigator.serviceWorker.register('/sw.js');
      const subscription=await registration.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:pushKeyBytes(pushState.config.publicKey)});
      try{await api('/push/subscriptions',{body:{...subscription.toJSON(),locale:lg}})}
      catch(error){await subscription.unsubscribe();throw error}
      pushState.subscription=subscription;pushState.status='on';toast(localizeText('Notifications enabled on this device'));
    }
    go('inbox');
  }catch(error){toast(localizeText(error.message||'Could not enable push notifications. Please try again.'))}
};

// Remove the account/device association before discarding its bearer token at sign-out.
const revokePushOnLogout=()=>{
  const token=sessionStorage.getItem('tk');
  if(!token||typeof navigator==='undefined'||!navigator.serviceWorker)return;
  navigator.serviceWorker.getRegistration().then(reg=>reg&&reg.pushManager.getSubscription()).then(sub=>{
    if(!sub)return;
    fetch('/gidan-api/push/unsubscribe',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify({endpoint:sub.endpoint})}).catch(()=>{});
    sub.unsubscribe().catch(()=>{});
  }).catch(()=>{});
};
