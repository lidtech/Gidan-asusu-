// Screen router: go(name) renders S[name] into #app.
const go=s=>{if(['home','cards','save','more'].includes(s))tab=s;A.innerHTML=S[s]();A.dataset.s=s;localizeNode(A);A.querySelector('.scr')?.scrollTo(0,0)};
