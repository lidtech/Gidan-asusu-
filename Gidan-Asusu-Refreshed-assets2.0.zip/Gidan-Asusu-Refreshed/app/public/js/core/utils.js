// Helpers: N() formats naira, A is the app root element.
const N=n=>'₦'+n.toLocaleString(lg==='ar'?'ar-EG':'en-NG'),A=document.getElementById('app');
// Escapes text from other users before it goes into HTML (stops script injection).
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
