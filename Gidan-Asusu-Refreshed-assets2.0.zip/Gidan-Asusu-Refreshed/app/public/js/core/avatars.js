// Profile photos. The user picks one on Account Details; the choice is stored on this device only (per email).
// With no choice the original initial-letter avatar is shown, exactly as before.
const AVATARS=[['business-owner','Business Owner'],['trader','Trader'],['student','Student'],['professional','Professional'],['farmer','Farmer']];
const avatarKey=()=>'gidan-avatar:'+(user.email||'');
const myAvatar=()=>{try{const a=localStorage.getItem(avatarKey())||'';return AVATARS.some(x=>x[0]===a)?a:''}catch{return ''}};
const avatarInner=()=>{const a=myAvatar();return a?`<img class="avatar-img" src="assets/avatar-${a}.png" alt="">`:esc(user.name[0])};
const setAvatar=k=>{try{k?localStorage.setItem(avatarKey(),k):localStorage.removeItem(avatarKey())}catch{}go('prof')};
const avatarPicker=()=>`<div class="card"><b>Profile photo</b><div class="avatar-pick">${AVATARS.map(a=>`<img class="avatar-img ${myAvatar()===a[0]?'on':''}" src="assets/avatar-${a[0]}.png" alt="${a[1]}" onclick="setAvatar('${a[0]}')">`).join('')}</div><div class="mu" style="margin-top:8px;cursor:pointer" onclick="setAvatar('')">Use my initial</div></div>`;
