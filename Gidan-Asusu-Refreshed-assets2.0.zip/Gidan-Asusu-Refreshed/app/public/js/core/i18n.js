// Languages: English, Hausa, Yoruba, Igbo, Pidgin and Arabic.
// Arabic is defined below (AR). Hausa/Yorùbá/Igbo/Pidgin live in lang-ha/yo/ig/pcm.js and are DRAFTS until a native speaker signs them off (docs/TRANSLATION_REVIEW.md).
const L={en:{hi:'Good morning',bal:'Total Balance',tr:'Transfer',air:'Airtime',bills:'Bills',more:'More',save:'Savings',cards:'Cards',home:'Home',loan:'Loans',farm:'Noma (Farm)',hist:'History',lang:'Language',recent:'Recent Transactions',signin:'Sign In',welcome:'Welcome Back',cont:'Continue',slogan:'Your Bank. Your Home.',goal:'Create New Goal',rew:'Savings Rewards',prof:'Profile',choose:'Choose app language'},
ar:{hi:'صباح الخير',bal:'إجمالي الرصيد',tr:'تحويل',air:'رصيد الهاتف',bills:'الفواتير',more:'المزيد',save:'الادخار',cards:'البطاقات',home:'الرئيسية',loan:'القروض',farm:'نوما (الزراعة)',hist:'السجل',lang:'اللغة',recent:'أحدث المعاملات',signin:'تسجيل الدخول',welcome:'مرحبًا بعودتك',cont:'متابعة',slogan:'مصرفك. بيتك.',goal:'إنشاء هدف ادخار',rew:'مكافآت الادخار',prof:'الملف الشخصي',choose:'اختر لغة التطبيق'}};
const LN={en:'English',ha:'Hausa',yo:'Yorùbá',ig:'Igbo',pcm:'Naijá Pidgin',ar:'العربية'};

// Arabic copy for every customer-facing screen, prompt, setting and common message.
// Exact text-node matching keeps customer names, account data and marketplace listings intact.
const AR={
'Choose app language':'اختر لغة التطبيق','Good morning':'صباح الخير','Total Balance':'إجمالي الرصيد','Transfer':'تحويل','Airtime':'رصيد الهاتف','Bills':'الفواتير','More':'المزيد','Savings':'الادخار','Cards':'البطاقات','Home':'الرئيسية','Loans':'القروض','Noma (Farm)':'نوما (الزراعة)','History':'السجل','Language':'اللغة','Recent Transactions':'أحدث المعاملات','Sign In':'تسجيل الدخول','Welcome Back':'مرحبًا بعودتك','Continue':'متابعة','Your Bank. Your Home.':'مصرفك. بيتك.','Create New Goal':'إنشاء هدف ادخار','Savings Rewards':'مكافآت الادخار','Profile':'الملف الشخصي',
'Safe. Simple. Always with you.':'آمن. بسيط. معك دائمًا.','Sign in to your account':'سجّل الدخول إلى حسابك','Email or Phone Number':'البريد الإلكتروني أو رقم الهاتف','Password':'كلمة المرور','Forgot Password?':'هل نسيت كلمة المرور؟','or':'أو','Create an Account':'إنشاء حساب','Create Account':'إنشاء حساب','Full name':'الاسم الكامل','Phone number (08012345678)':'رقم الهاتف (08012345678)','Email':'البريد الإلكتروني','Password (8+ characters, letters and numbers)':'كلمة مرور من 8 أحرف على الأقل، تتضمن حروفًا وأرقامًا','Choose a 4-digit transaction PIN':'اختر رقمًا سريًا للمعاملات من 4 أرقام','Your PIN approves every payment. Never share it.':'رقمك السري يوافق على كل دفعة. لا تشاركه أبدًا.','I already have an account':'لدي حساب بالفعل','Reset password':'إعادة تعيين كلمة المرور','Enter your email or phone number and we will send a 6-digit code.':'أدخل بريدك الإلكتروني أو رقم هاتفك لنرسل إليك رمزًا من 6 أرقام.','Enter the 6-digit code we sent to':'أدخل الرمز المكوّن من 6 أرقام الذي أرسلناه إلى','6-digit code':'رمز من 6 أرقام','New password (8+ characters, letters and numbers)':'كلمة مرور جديدة من 8 أحرف على الأقل، تتضمن حروفًا وأرقامًا','Reset password':'إعادة تعيين كلمة المرور','Send a new code':'إرسال رمز جديد','Send code':'إرسال الرمز',
'Save for a brighter future':'ادخر لمستقبل أفضل','Start from just ₦2,000 · earn rewards':'ابدأ من ₦2,000 فقط واكسب المكافآت','See all':'عرض الكل','↑ +₦12,300.00 (today)':'↑ +₦12,300.00 (اليوم)','Recipient account number':'رقم حساب المستفيد','To Gidan asusu':'إلى حساب جي دان أسوسو','To Bank':'إلى بنك','To Others':'إلى شخص آخر','Bank details':'بيانات البنك','10-digit Gidan asusu account number':'رقم حساب جي دان أسوسو المكوّن من 10 أرقام','10-digit account number':'رقم الحساب المكوّن من 10 أرقام','Recipient phone number':'رقم هاتف المستفيد','Gidan asusu user\'s phone e.g. 0803 000 0000':'رقم هاتف مستخدم جي دان أسوسو، مثل 0803 000 0000','Amount':'المبلغ','₦ Enter amount':'أدخل المبلغ ₦','Description (Optional)':'الوصف (اختياري)','e.g. Rent, Food, etc.':'مثل الإيجار أو الطعام','Transfer Successful!':'تم التحويل بنجاح!','has been sent to':'تم الإرسال إلى','Recipient':'المستفيد','Account / Phone':'الحساب / الهاتف','Bank':'البنك','Reference':'المرجع','View Receipt':'عرض الإيصال','Back to Home':'العودة إلى الرئيسية','Receipt':'الإيصال','Narration':'البيان','Date':'التاريخ','Status':'الحالة','Successful':'ناجح',
'DEBIT':'مدين','VALID THRU 08/29':'صالح حتى 08/29','Unlock Card':'إلغاء قفل البطاقة','Lock Card':'قفل البطاقة','Card Settings':'إعدادات البطاقة','Add to Wallet':'إضافة إلى المحفظة','Recent Card Transactions':'أحدث معاملات البطاقة','Online payments':'المدفوعات عبر الإنترنت','ATM withdrawals':'السحب من أجهزة الصراف','International use':'الاستخدام الدولي','On':'مفعّل','Off':'متوقف','Change PIN':'تغيير الرقم السري','PIN change link sent by SMS':'تم إرسال رابط تغيير الرقم السري عبر رسالة نصية','Card locked':'تم قفل البطاقة','Card unlocked':'تم إلغاء قفل البطاقة','Card added to wallet':'تمت إضافة البطاقة إلى المحفظة',
'Total Savings':'إجمالي المدخرات','Earning':'العائد','a year':'سنويًا','interest paid so far':'الفائدة المدفوعة حتى الآن','Minimum deposit ₦2,000. Bigger savings, bigger rewards.':'الحد الأدنى للإيداع ₦2,000. كلما زاد الادخار زادت المكافآت.','Base interest 8% p.a.':'فائدة أساسية 8% سنويًا','+2% bonus & cashback':'مكافأة إضافية 2% واسترداد نقدي','+4% bonus & loan discount':'مكافأة إضافية 4% وخصم على القرض','Savings Goals':'أهداف الادخار','All goals are shown':'تظهر جميع الأهداف','Goal name':'اسم الهدف','Target amount (min ₦2,000)':'المبلغ المستهدف (الحد الأدنى ₦2,000)','Minimum target is ₦2,000':'الحد الأدنى للمبلغ المستهدف هو ₦2,000','Minimum deposit is ₦2,000.':'الحد الأدنى للإيداع هو ₦2,000.','Add Money':'إضافة أموال','Withdraw to wallet':'السحب إلى المحفظة','You have less than that saved here':'مدخراتك هنا أقل من هذا المبلغ','moved to your wallet':'تم نقله إلى محفظتك','added':'تمت الإضافة',
'Pay Bills':'دفع الفواتير','Electricity':'الكهرباء','Water':'المياه','Data':'البيانات','Cable TV':'التلفزيون المدفوع','Education':'التعليم','Insurance':'التأمين','Other':'أخرى','Recent Bills':'أحدث الفواتير','Meter / account / smartcard number':'رقم العداد أو الحساب أو البطاقة الذكية','₦ Amount':'المبلغ ₦','Pay now':'ادفع الآن','Enter the number and amount':'أدخل الرقم والمبلغ','paid for':'تم دفعها مقابل','Search produce, seller or location':'ابحث عن المنتجات أو البائع أو الموقع','Sell':'بيع','Buy':'شراء','Orders':'الطلبات','All':'الكل','Grains':'الحبوب','Vegetables':'الخضروات','Livestock':'الماشية','Buy':'شراء','No produce listed yet. Be the first to sell.':'لا توجد منتجات معروضة بعد. كن أول بائع.','Your payment is held safely until you confirm delivery.':'سيُحتفظ بأموالك بأمان حتى تؤكد استلام الطلب.','List your produce':'اعرض منتجاتك','What are you selling? e.g. Sorghum':'ما المنتج الذي تبيعه؟ مثلًا: الذرة الرفيعة','₦ Price per unit':'السعر للوحدة ₦','How many units do you have?':'كم وحدة لديك؟','Location e.g. Kano':'الموقع، مثل كانو','List Produce':'عرض المنتج','Tap to change':'اضغط للتغيير','Your listings':'منتجاتك المعروضة','Remove':'إزالة','Orders to fulfil':'طلبات بانتظار التنفيذ','Mark as shipped':'تحديد كطلب مُرسل','Decline and refund buyer':'رفض الطلب ورد المبلغ للمشتري','Confirm delivery':'تأكيد الاستلام','Report a problem':'الإبلاغ عن مشكلة','Cancel order (full refund)':'إلغاء الطلب (استرداد كامل)','No orders yet. Browse the Buy tab to place your first order.':'لا توجد طلبات بعد. تصفّح تبويب الشراء لتقديم أول طلب.','Search':'بحث','Buy (held safely)':'ادفع (سيُحتفظ بالمبلغ بأمان)','Pay (held safely)':'ادفع (سيُحتفظ بالمبلغ بأمان)','Choose a quantity':'اختر الكمية','Order placed. Your money is held safely.':'تم تقديم الطلب. أموالك محفوظة بأمان.','Marked as shipped':'تم تحديد الطلب كمُرسل','Delivery confirmed. Seller paid.':'تم تأكيد الاستلام ودفع المبلغ للبائع.','Order cancelled. The buyer is refunded.':'تم إلغاء الطلب ورد المبلغ للمشتري.','Dispute opened':'تم فتح نزاع','Listed!':'تم عرض المنتج','Not delivered':'لم يتم التسليم','Poor quality':'جودة منخفضة','Wrong quantity':'كمية غير صحيحة','Other problem':'مشكلة أخرى',
'You qualify for up to':'يمكنك الحصول على قرض يصل إلى','Based on your account history · 5% monthly, 1–12 months':'وفقًا لسجل حسابك · فائدة شهرية 5%، من شهر إلى 12 شهرًا','Keep saving to qualify':'واصل الادخار لتكون مؤهلًا','Loan amount':'مبلغ القرض','Repayment period':'مدة السداد','3 months':'3 أشهر','6 months':'6 أشهر','12 months':'12 شهرًا','Your application is being reviewed by our credit team.':'يراجع فريق الائتمان طلبك.','Apply for Loan':'تقديم طلب قرض','Active loan':'قرض نشط','Remaining':'المتبقي','of':'من','₦ Repay amount':'مبلغ السداد ₦','Repay':'سداد','Loans start at ₦5,000':'تبدأ القروض من ₦5,000','Loan decision':'قرار القرض','Done':'تم','Repayment received':'تم استلام السداد',
'Account Details':'تفاصيل الحساب','Fund Transfer Limits':'حدود التحويل','Notifications':'الإشعارات','Help & Support':'المساعدة والدعم','About Gidan asusu':'نبذة عن جي دان أسوسو','Add Money (sandbox)':'إضافة أموال (بيئة اختبار)','Log Out':'تسجيل الخروج','Per transaction':'لكل معاملة','Daily transfers':'التحويلات اليومية','Bills & airtime daily':'الفواتير ورصيد الهاتف يوميًا','Request increase':'طلب زيادة الحد','Limit increase request sent':'تم إرسال طلب زيادة الحد','Call':'اتصال','Hours':'ساعات العمل','Chat with us':'تواصل معنا','Connecting you to support…':'جارٍ توصيلك بالدعم…','Version':'الإصدار','Savings':'الادخار','From ₦2,000 with rewards':'ابتداءً من ₦2,000 مع مكافآت','English, Hausa, Yorùbá, Igbo, Pidgin, Arabic':'الإنجليزية، والهوسا، واليوروبا، والإيغبو، والبيجين، والعربية','Live deposits arrive by bank transfer to your account number:':'تصل الإيداعات الحقيقية عبر تحويل مصرفي إلى رقم حسابك:','₦ Test amount':'مبلغ تجريبي ₦','Add test money':'إضافة أموال تجريبية','Password reset needs an email/SMS provider (not connected yet)':'إعادة تعيين كلمة المرور تتطلب ربط خدمة البريد الإلكتروني أو الرسائل النصية.','Send reset code':'إرسال رمز إعادة التعيين',
'Account tier':'فئة الحساب','Identity check':'التحقق من الهوية','Not started':'لم يبدأ','In review':'قيد المراجعة','Verified':'تم التحقق','Needs attention':'يتطلب الانتباه','Verify your identity':'تحقق من هويتك','Verify BVN or NIN first, then come back here.':'تحقق من رقم BVN أو NIN أولًا، ثم عُد إلى هنا.','Verify BVN or NIN':'التحقق من BVN أو NIN','You are fully verified':'تم التحقق من هويتك بالكامل','Your documents are in review. We will update you within 24 hours.':'مستنداتك قيد المراجعة. سنوافيك بالتحديث خلال 24 ساعة.','Verified accounts get the highest limits. Your documents are only used to confirm who you are.':'تحصل الحسابات الموثقة على أعلى الحدود. تُستخدم مستنداتك للتحقق من هويتك فقط.','Government ID (NIN slip, voter\'s card, licence or passport)':'هوية حكومية (إفادة NIN أو بطاقة ناخب أو رخصة أو جواز سفر)','Selfie holding your ID':'صورة ذاتية وأنت تحمل هويتك','Submit for review':'إرسال للمراجعة','Choose both files first':'اختر الملفين أولًا','PDF must be under 1 MB':'يجب أن يكون حجم ملف PDF أقل من 1 ميغابايت','Could not read that image':'تعذرت قراءة الصورة','Submitted. We will review within 24 hours.':'تم الإرسال. سنراجع طلبك خلال 24 ساعة.',
'Noma — grow with Gidan asusu':'نوما — ازدهر مع جي دان أسوسو','Savings, loans and market tools for farmers':'أدوات الادخار والقروض والسوق للمزارعين','Farm Loan':'قرض زراعي','Livestock Plan':'خطة الماشية','Harvest Savings':'مدخرات الحصاد','Market Prices':'أسعار السوق','Weather & Planting':'الطقس والزراعة','Crop Insurance':'تأمين المحاصيل','Input Credit':'ائتمان مستلزمات الزراعة','Co-op Groups':'المجموعات التعاونية','Sell Produce':'بيع المنتجات','Save a little weekly during the season. Funds unlock at harvest time, with bonus interest.':'ادخر مبلغًا صغيرًا كل أسبوع خلال الموسم. تصبح الأموال متاحة وقت الحصاد مع فائدة إضافية.','Save toward goats, cattle or poultry. Start from ₦2,000.':'ادخر لشراء الماعز أو الأبقار أو الدواجن. ابدأ من ₦2,000.','Start plan with ₦2,000':'ابدأ الخطة بـ ₦2,000','Sample data':'بيانات تجريبية','Today':'اليوم','Rain likely':'يُحتمل هطول الأمطار','Advice':'نصيحة','Plant maize after two rain days':'ازرع الذرة بعد يومين ممطرين','Get a quote':'طلب عرض سعر','members':'أعضاء','Join':'انضمام','Request sent to':'تم إرسال الطلب إلى',
'Harvest savings balance':'رصيد مدخرات الحصاد','Earning':'العائد','Auto-save from sales':'الادخار التلقائي من المبيعات','When a sale completes, this share goes straight into Harvest Savings and the rest to your wallet.':'عند إتمام البيع، يُضاف هذا الجزء مباشرة إلى مدخرات الحصاد ويُحوّل الباقي إلى محفظتك.','Share of each sale':'نسبة كل عملية بيع','Example: a ₦48,000 sale saves':'مثال: بيع بقيمة ₦48,000 يدخر','and sends':'ويحوّل','to your wallet.':'إلى محفظتك.','of each sale will be saved':'من كل عملية بيع إلى الادخار','Auto-save turned off':'تم إيقاف الادخار التلقائي',
'SMS alerts':'تنبيهات الرسائل النصية','Texts for money, loans, ID checks and security. Security texts always go out.':'رسائل بشأن الأموال والقروض والتحقق من الهوية والأمان. تُرسل التنبيهات الأمنية دائمًا.','On':'مفعّل','Off':'متوقف','Nothing yet. We will tell you here when something happens.':'لا توجد إشعارات بعد. سنخبرك هنا عند حدوث أي جديد.','Push notifications':'الإشعارات الفورية','Get secure alerts on this installed app, even when it is closed.':'استقبل تنبيهات آمنة في هذا التطبيق المثبّت حتى عند إغلاقه.','Enable push notifications':'تفعيل الإشعارات الفورية','Disable push notifications':'إيقاف الإشعارات الفورية','Push notifications are on for this device.':'الإشعارات الفورية مفعّلة على هذا الجهاز.','Push notifications are off for this device.':'الإشعارات الفورية متوقفة على هذا الجهاز.','Push is not supported in this browser.':'هذا المتصفح لا يدعم الإشعارات الفورية.','Push delivery is not configured yet. The app administrator must add VAPID keys.':'لم يتم إعداد الإشعارات الفورية بعد. على مسؤول التطبيق إضافة مفاتيح VAPID.','Allow notifications in your browser settings, then try again.':'اسمح بالإشعارات من إعدادات المتصفح، ثم حاول مرة أخرى.','Notifications enabled on this device':'تم تفعيل الإشعارات على هذا الجهاز','Notifications disabled on this device':'تم إيقاف الإشعارات على هذا الجهاز','Could not enable push notifications. Please try again.':'تعذر تفعيل الإشعارات الفورية. حاول مرة أخرى.','Could not disable push notifications. Please try again.':'تعذر إيقاف الإشعارات الفورية. حاول مرة أخرى.','Choose app language':'اختر لغة التطبيق',
'Settings':'الإعدادات','Log Out':'تسجيل الخروج','Verify your identity: BVN or NIN (unlock loans & higher limits)':'تحقق من هويتك: BVN أو NIN (للوصول إلى القروض وحدود أعلى)','Verify identity (ID + selfie) for the highest limits':'تحقق من الهوية (بطاقة الهوية والصورة الذاتية) للحصول على أعلى الحدود','Acct':'الحساب','Tier':'الفئة','Your profile':'ملفك الشخصي','Money received':'تم استلام أموال','Loan approved':'تمت الموافقة على القرض','Loan not approved':'لم تتم الموافقة على القرض','Loan under review':'القرض قيد المراجعة','Identity verified':'تم التحقق من الهوية','Identity check needs attention':'التحقق من الهوية يتطلب الانتباه','Documents received':'تم استلام المستندات','New order':'طلب جديد','Order shipped':'تم شحن الطلب','Order cancelled':'تم إلغاء الطلب','Dispute opened':'تم فتح نزاع','Dispute resolved':'تم حل النزاع','Payment received':'تم استلام الدفعة','Refund received':'تم استرداد المبلغ','Interest paid':'تم دفع الفائدة','Password changed':'تم تغيير كلمة المرور','PIN locked':'تم قفل الرقم السري','Account locked':'تم قفل الحساب','Security alert':'تنبيه أمني','Password changed. Please sign in.':'تم تغيير كلمة المرور. سجّل الدخول من فضلك.','Your limits have been raised and loans are unlocked.':'تم رفع حدود حسابك وإتاحة القروض.','Open the app to view details.':'افتح التطبيق لعرض التفاصيل.','Choose app language':'اختر لغة التطبيق'
};
Object.assign(AR,{
 'Wallet funding (sandbox)':'تمويل المحفظة (بيئة الاختبار)','Salary Credit':'إيداع الراتب','Airtime Purchase':'شراء رصيد الهاتف','Verify your BVN or NIN first, then come back here.':'تحقق من رقم BVN أو NIN أولًا، ثم عُد إلى هنا.','Verify identity':'التحقق من الهوية','Phone':'الهاتف','Balance':'الرصيد','Account':'الحساب','Languages':'اللغات','Noma Market':'سوق نوما','Paid · held safely':'مدفوع · محفوظ بأمان','Shipped':'تم الشحن','Completed':'مكتمل','Dispute open':'نزاع مفتوح','Refunded':'تم رد المبلغ','Pending':'قيد الانتظار','pending':'قيد الانتظار','approved':'تمت الموافقة','rejected':'مرفوض','Test money added':'تمت إضافة أموال تجريبية','Welcome to Gidan asusu!':'مرحبًا بك في جي دان أسوسو!','Enter your email/phone and password':'أدخل بريدك الإلكتروني أو رقم هاتفك وكلمة المرور','Please sign in again':'سجّل الدخول مرة أخرى من فضلك','Something went wrong':'حدث خطأ ما','Phone number or email':'رقم الهاتف أو البريد الإلكتروني','Full name':'الاسم الكامل','Goal name':'اسم الهدف','Target amount (min ₦2,000)':'المبلغ المستهدف (الحد الأدنى ₦2,000)','Choose a valid recipient first':'أدخل بيانات مستفيد صحيحة أولًا','Saved':'تم الادخار','Interest paid':'تم دفع الفائدة','Savings interest paid':'تم دفع فائدة الادخار','Order completed':'اكتمل الطلب','Your limits have been raised.':'تم رفع حدود حسابك.','Enter an amount':'أدخل المبلغ','Recipient not found':'لم يتم العثور على المستفيد','Account not found':'لم يتم العثور على الحساب','You cannot send money to yourself':'لا يمكنك إرسال أموال إلى نفسك','Insufficient funds':'الرصيد غير كافٍ','Enter the number and amount':'أدخل الرقم والمبلغ','Enter a valid recipient first':'أدخل بيانات مستفيد صحيحة أولًا'
});

Object.assign(AR,{
"No BVN? Use your NIN instead.": "لا تملك BVN؟ استخدم رقم NIN بدلًا منه.",
"Verify": "تحقق",
"Verified: higher limits and loans unlocked": "تم التحقق: رُفعت الحدود وأُتيحت القروض",
"Sample data for demo": "بيانات تجريبية للعرض",
"Confirm": "تأكيد",
"Add money (sandbox)": "إضافة أموال (بيئة الاختبار)",
"Quote request sent": "تم إرسال طلب عرض السعر",
"Enter transaction PIN": "أدخل الرقم السري للمعاملة",
"4-digit PIN": "رقم سري من 4 أرقام",
"Electricity (IBEDC)": "الكهرباء (IBEDC)",
"Data (MTN)": "البيانات (MTN)",
"Thursday": "الخميس",
"Crop Basic": "المحاصيل الأساسية (Crop Basic)",
"Livestock Cover": "تغطية الماشية (Livestock Cover)",
"Enter your email or phone number": "أدخل بريدك الإلكتروني أو رقم هاتفك",
"Total:": "الإجمالي:",
"Open dispute": "فتح نزاع",
"Minimum deposit is ₦2,000": "الحد الأدنى للإيداع ₦2,000",
"↪ Log Out": "↪ تسجيل الخروج"
});
Object.assign(AR,{'Profile photo':'الصورة الشخصية','Use my initial':'استخدام الحرف الأول من اسمي'});
Object.setPrototypeOf(AR,null);

// Other languages: nav labels are derived from each language's dictionary so there is a single source of truth.
const LK={hi:'Good morning',bal:'Total Balance',tr:'Transfer',air:'Airtime',bills:'Bills',more:'More',save:'Savings',cards:'Cards',home:'Home',loan:'Loans',farm:'Noma (Farm)',hist:'History',lang:'Language',recent:'Recent Transactions',signin:'Sign In',welcome:'Welcome Back',cont:'Continue',slogan:'Your Bank. Your Home.',goal:'Create New Goal',rew:'Savings Rewards',prof:'Profile',choose:'Choose app language'};
// Regexes for dynamic messages; every TR[x].p template list is index-aligned with this array.
const TRX=[
"^Transfer to (.+)$",
"^Transfer from (.+)$",
"^Savings interest: (.+)$",
"^Order: (.+)$",
"^(.+) payment$",
"^Tier (\\d+)$",
"^Acct (\\d+) · Gidan asusu$",
"^Earning (\\d+)% a year · (.+) interest paid so far$",
"^Earning (\\d+)% a year like all savings$",
"^Verify your BVN to unlock loans(?: · score \\d+/100)?$",
"^(.+) has been sent to (.+)$",
"^(.+) paid for (.+)$",
"^Enter the 6-digit code we sent to (.+), then choose a new password\\.$",
"^Sandbox code: (\\d{6})$",
"^(.+) added$",
"^(.+) moved to your wallet$",
"^Example: a ₦48,000 sale saves (.+) and sends (.+) to your wallet\\.$",
"^(.+) is now in your account\\. You will repay (.+) \\((.+) a month\\)\\.$",
"^Approved! (.+)$",
"^Not approved\\. (.*)$",
"^Sent for review\\. (.*)$",
"^Your transaction PIN was locked after (\\d+) wrong tries\\. Contact support if this was not you\\.$",
"^Too many wrong passwords\\. Sign-in is paused for (\\d+) minutes\\. Contact support if this was not you\\.$",
"^Your password was just changed\\. If this was not you, contact support now\\.$",
"^Our credit team will decide soon\\. We will message you\\.$",
"^(\\d+) x (.+) for ₦([\\d,.]+)\\. Ship it to get paid\\.$",
"^(.+) is on its way\\. Confirm when it arrives\\.$",
"^The buyer reported a problem with (.+)\\. Our team will review it\\.$",
"^(.+) was cancelled by the buyer\\.$",
"^(.+) was declined by the seller and you have been refunded\\.$",
"^₦([\\d,.]+) for (.+) is back in your wallet\\.$",
"^₦([\\d,.]+) from (.+)$",
"^₦([\\d,.]+) was added to (.+)\\.$",
"^₦([\\d,.]+) for (.+)$",
"^(.+): the seller has been paid\\.$",
"^(BVN|NIN) verified$",
"^Build a history: receive regular deposits and save more$",
"^Repay your current loan first$",
"^Open the app for details\\.$",
"^₦([\\d,.]+) has been paid into your account\\.?$",
"^The name on that (BVN|NIN) does not match your account name\\..*$",
"^(\\d+) members$",
"^Request sent to (.+)$"
].map(r=>new RegExp(r));
for(const c of Object.keys(TR)){TR[c].d=Object.assign(Object.create(null),TR[c].d);L[c]=Object.fromEntries(Object.entries(LK).map(([k,e])=>[k,TR[c].d[e]||L.en[k]]))}
const DATE_RE=/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{1,2}, \d{4}$/;
const localizeOther=value=>{
 const T=TR[lg];if(!T)return value;
 const s=value.replace(/\s+/g,' ').trim();if(s in T.d)return T.d[s];
 for(let i=0;i<TRX.length;i++){if(T.p[i]&&TRX[i].test(s))return s.replace(TRX[i],T.p[i])}
 let m;
 if((m=s.match(/^(.+) · score (\d+)\/100$/)))return `${localizeOther(m[1])} · ${T.score} ${m[2]}/100`;
 if(DATE_RE.test(s)){const d=new Date(s);if(!Number.isNaN(d.getTime())){try{return d.toLocaleDateString(T.loc,{month:'short',day:'numeric',year:'numeric'})}catch{}}}
 return value;
};

const t=k=>L[lg]?.[k]||L.en[k]||k;
const applyLanguage=()=>{if(typeof document==='undefined'||!document.documentElement)return;document.documentElement.lang=lg;document.documentElement.dir=lg==='ar'?'rtl':'ltr'};
const setLanguage=k=>{if(!L[k])return;lg=k;try{localStorage.setItem('gidan-language',k)}catch{}applyLanguage();if(typeof syncPushLocale==='function')syncPushLocale();go('lang')};
const localizeText=value=>{
 if(lg==='en'||typeof value!=='string')return value;
 if(lg!=='ar')return localizeOther(value);
 const s=value.replace(/\s+/g,' ').trim();if(AR[s])return AR[s];
 let m;
 if((m=s.match(/^Transfer to (.+)$/)))return `تحويل إلى ${m[1]}`;
 if((m=s.match(/^Transfer from (.+)$/)))return `تحويل من ${m[1]}`;
 if((m=s.match(/^Savings interest: (.+)$/)))return `فائدة الادخار: ${m[1]}`;
 if((m=s.match(/^Order: (.+)$/)))return `طلب: ${m[1]}`;
 if((m=s.match(/^(.+) payment$/)))return `دفعة ${m[1]}`;
  if((m=s.match(/^Tier (\d+)$/)))return `الفئة ${m[1]}`;
  if((m=s.match(/^Acct (\d+) · Gidan asusu$/)))return `الحساب ${m[1]} · جي دان أسوسو`;
  if((m=s.match(/^Earning (\d+)% a year · (.+) interest paid so far$/)))return `عائد سنوي بنسبة ${m[1]}% · الفائدة المدفوعة حتى الآن ${m[2]}`;
  if((m=s.match(/^Earning (\d+)% a year like all savings$/)))return `عائد سنوي بنسبة ${m[1]}% مثل بقية المدخرات`;
  if((m=s.match(/^Verify your BVN to unlock loans(?: · score \d+\/100)?$/)))return 'تحقق من رقم BVN لإتاحة القروض';
  if((m=s.match(/^(.+) has been sent to (.+)$/)))return `تم إرسال ${m[1]} إلى ${m[2]}`;
  if((m=s.match(/^(.+) paid for (.+)$/)))return `تم دفع ${m[1]} مقابل ${m[2]}`;
  if((m=s.match(/^Enter the 6-digit code we sent to (.+), then choose a new password\.$/)))return `أدخل الرمز المكوّن من 6 أرقام الذي أرسلناه إلى ${m[1]}، ثم اختر كلمة مرور جديدة.`;
  if((m=s.match(/^Sandbox code: (\d{6})$/)))return `رمز بيئة الاختبار: ${m[1]}`;
  if((m=s.match(/^(.+) added$/)))return `تمت إضافة ${m[1]}`;
  if((m=s.match(/^(.+) moved to your wallet$/)))return `تم تحويل ${m[1]} إلى محفظتك`;
  if((m=s.match(/^Example: a ₦48,000 sale saves (.+) and sends (.+) to your wallet\.$/)))return `مثال: بيع بقيمة ₦48,000 يضيف ${m[1]} إلى المدخرات ويحوّل ${m[2]} إلى محفظتك.`;
  if((m=s.match(/^Your application is being reviewed by our credit team\.$/)))return 'يراجع فريق الائتمان طلبك.';
  if((m=s.match(/^(.+) is now in your account\. You will repay (.+) \((.+) a month\)\.$/)))return `تم إيداع ${m[1]} في حسابك. ستسدد ${m[2]} (${m[3]} شهريًا).`;
  if((m=s.match(/^Approved! (.+)$/)))return `تمت الموافقة! ${m[1]}`;
  if((m=s.match(/^Not approved\. (.*)$/)))return `لم تتم الموافقة. ${m[1]}`;
  if((m=s.match(/^Sent for review\. (.*)$/)))return `أُرسل الطلب للمراجعة. ${m[1]}`;
  if((m=s.match(/^Your transaction PIN was locked after (\d+) wrong tries\. Contact support if this was not you\.$/)))return `تم قفل الرقم السري للمعاملات بعد إدخال خاطئ ${m[1]} مرات. تواصل مع الدعم إذا لم تكن أنت.`;
  if((m=s.match(/^Too many wrong passwords\. Sign-in is paused for (\d+) minutes\. Contact support if this was not you\.$/)))return `توقّف تسجيل الدخول مؤقتًا لمدة ${m[1]} دقيقة بسبب تكرار كلمات المرور الخاطئة. تواصل مع الدعم إذا لم تكن أنت.`;
  if((m=s.match(/^Your password was just changed\. If this was not you, contact support now\.$/)))return 'تم تغيير كلمة مرورك للتو. تواصل مع الدعم فورًا إذا لم تكن أنت.';
  if((m=s.match(/^Our credit team will decide soon\. We will message you\.$/)))return 'سيتخذ فريق الائتمان قراره قريبًا وسنرسل إليك رسالة.';
  if((m=s.match(/^(\d+) x (.+) for ₦([\d,.]+)\. Ship it to get paid\.$/)))return `طلب جديد: ${m[1]} × ${m[2]} بقيمة ₦${m[3]}. أرسل الطلب لاستلام المبلغ.`;
  if((m=s.match(/^(.+) is on its way\. Confirm when it arrives\.$/)))return `${m[1]} في الطريق إليك. أكّد الاستلام عند وصوله.`;
  if((m=s.match(/^The buyer reported a problem with (.+)\. Our team will review it\.$/)))return `أبلغ المشتري عن مشكلة في ${m[1]}. سيراجع فريقنا الأمر.`;
  if((m=s.match(/^(.+) was cancelled by the buyer\.$/)))return `ألغى المشتري الطلب: ${m[1]}.`;
  if((m=s.match(/^(.+) was declined by the seller and you have been refunded\.$/)))return `رفض البائع الطلب ${m[1]} وتم رد المبلغ إليك.`;
  if((m=s.match(/^₦([\d,.]+) for (.+) is back in your wallet\.$/)))return `عاد مبلغ ₦${m[1]} الخاص بـ ${m[2]} إلى محفظتك.`;
 if((m=s.match(/^₦([\d,.]+) from (.+)$/)))return `تم استلام ₦${m[1]} من ${m[2]}`;
  if((m=s.match(/^₦([\d,.]+) was added to (.+)\.$/)))return `أُضيف مبلغ ₦${m[1]} إلى ${m[2]}.`;
  if((m=s.match(/^₦([\d,.]+) for (.+)$/)))return `₦${m[1]} مقابل ${m[2]}`;
  if((m=s.match(/^(.+): the seller has been paid\.$/)))return `${m[1]}: تم دفع المبلغ للبائع.`;
  if((m=s.match(/^(BVN|NIN) verified$/)))return `تم التحقق من ${m[1]}`;
  if((m=s.match(/^Build a history: receive regular deposits and save more$/)))return 'أنشئ سجلًا جيدًا: استقبل إيداعات منتظمة وزد مدخراتك.';
  if((m=s.match(/^Repay your current loan first$/)))return 'سدد قرضك الحالي أولًا.';
  if((m=s.match(/^Open the app for details\.$/)))return 'افتح التطبيق للاطلاع على التفاصيل.';
 if((m=s.match(/^₦([\d,.]+) has been paid into your account\.?$/)))return `تم إيداع ₦${m[1]} في حسابك.`;
 if((m=s.match(/^The name on that (BVN|NIN) does not match your account name\..*$/)))return `الاسم المسجل في ${m[1]} لا يطابق اسم حسابك. تحقق من بياناتك أو تواصل مع الدعم.`;

 if((m=s.match(/^(\d+) members$/)))return `${m[1]} عضوًا`;
 if((m=s.match(/^Request sent to (.+)$/)))return `تم إرسال الطلب إلى ${m[1]}`;
 if((m=s.match(/^(.+) · score (\d+)\/100$/)))return `${localizeText(m[1])} · النتيجة ${m[2]}/100`;
 if(/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{1,2}, \d{4}$/.test(s)){const d=new Date(s);if(!Number.isNaN(d.getTime()))return d.toLocaleDateString('ar-EG',{month:'short',day:'numeric',year:'numeric'})}
 return AR[s]||value;
};
const localizeNode=root=>{
 if(lg==='en'||!root||typeof document==='undefined'||typeof document.createTreeWalker!=='function')return;
 const walker=document.createTreeWalker(root,typeof NodeFilter==='undefined'?4:NodeFilter.SHOW_TEXT);
 let n;while((n=walker.nextNode())){if(n.parentElement?.closest('script,style'))continue;const raw=n.nodeValue,trim=raw.trim();if(!trim)continue;const out=localizeText(trim);if(out!==trim)n.nodeValue=raw.replace(trim,out)}
 if(typeof root.querySelectorAll==='function')root.querySelectorAll('[placeholder],[title],[aria-label]').forEach(el=>['placeholder','title','aria-label'].forEach(a=>{if(el.hasAttribute(a))el.setAttribute(a,localizeText(el.getAttribute(a)))}));
};
applyLanguage();
