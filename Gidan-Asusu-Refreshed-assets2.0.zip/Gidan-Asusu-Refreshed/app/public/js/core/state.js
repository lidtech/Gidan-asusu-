// Shared app state. Loaded first; every other file reads these globals.
const S={}; // screen registry: S.name = () => html string
const TR={}; // translation packs (lang-*.js register here; i18n.js reads them)
let lg=(()=>{try{const saved=localStorage.getItem('gidan-language');return ['en','ha','yo','ig','pcm','ar'].includes(saved)?saved:'en'}catch{return 'en'}})(),tab='home',goals=[['Dream Home',30000,500000,'home'],['Travel',15000,300000,'transfer'],['Emergency Fund',10000,200000,'shield']];
let idm=['bvn'];
let nt={items:[],unread:0};
let sv={ratePct:8,earned:0,pending:0},fpStep=1,fpId='';
let user={name:'Guest',email:'',phone:'',tier:1},acct={number:''},elig={limit:0,score:0,reasons:[],decision:'decline',active:null};
