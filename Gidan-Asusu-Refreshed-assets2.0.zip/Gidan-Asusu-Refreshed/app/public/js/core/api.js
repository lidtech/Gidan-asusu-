// Talks to the backend (server/server.js). Token is kept in sessionStorage for this prototype;
// use httpOnly cookies (web) or the secure keychain (mobile) in production.
const api=async(path,o={})=>{const h={'Content-Type':'application/json'},tk=sessionStorage.getItem('tk');if(tk)h.Authorization='Bearer '+tk;
  if(o.idem)h['Idempotency-Key']=(crypto.randomUUID?crypto.randomUUID():Date.now()+'-'+Math.random());
  let r;try{r=await fetch('/gidan-api'+path,{method:o.body?'POST':'GET',headers:h,body:o.body?JSON.stringify(o.body):undefined})}catch{throw new Error('Cannot reach the server. Start it with: npm start')}
  const d=await r.json().catch(()=>({}));if(r.status==401&&tk&&!path.startsWith('/auth/')){logout();throw new Error(localizeText('Please sign in again'))}
  if(!r.ok)throw new Error(localizeText(d.error||'Something went wrong'));return d};
const logout=()=>{revokePushOnLogout();sessionStorage.removeItem('tk');user={name:'Guest',email:'',phone:'',tier:1};go('login')};
const ICON={bill:'bill',transfer_out:'transfer',bank_out:'transfer',transfer_in:'coin',fund:'coin',loan:'coin',loan_repay:'transfer',savings:'save',reversal:'history',interest:'star'};
const fmt=ms=>new Date(ms).toLocaleDateString(lg==='ar'?'ar-EG':'en-US',{month:'short',day:'numeric',year:'numeric'});
// Reloads everything the screens show from the server (balance, history, goals, loan eligibility).
const refresh=async()=>{const [me,t,g,l,n]=await Promise.all([api('/me'),api('/transactions'),api('/savings'),api('/loans'),api('/notifications')]);
  user=me.user;idm=me.methods||['bvn'];acct=me.account;bal=me.account.balance;elig=l;nt=n;tx.length=0;
  t.items.forEach(x=>tx.push([ICON[x.kind]||'•',x.label,fmt(x.created_at),x.amount]));
  billList=t.items.filter(x=>x.kind=='bill').map(x=>[x.label.replace(' payment',''),fmt(x.created_at),-x.amount]);
  goals=g.items.map(x=>[x.name,x.saved,x.target,x.icon,x.id]);sv={ratePct:g.ratePct,earned:g.earned,pending:g.pending}};
const devFund=async()=>{const a=+document.getElementById('fa').value;try{await api('/dev/fund',{body:{amount:a}});await refresh();closeSheet();go(A.dataset.s);toast('Test money added')}catch(e){toast(e.message)}};
let idKind='bvn';
const verifyBvn=()=>{if(!idm.includes(idKind))idKind='bvn';const K=idKind.toUpperCase();
  sheet('Verify your identity',`${idm.length>1?`<div class="row" style="margin-bottom:8px">${idm.map(k=>`<span class="pill" style="cursor:pointer;${k==idKind?'background:var(--g1);color:#fff':''}" onclick="idKind='${k}';verifyBvn()">${k.toUpperCase()}</span>`).join('')}</div><p class="mu">No BVN? Use your NIN instead.</p>`:''}<input class="in" id="bv" inputmode="numeric" maxlength="11" placeholder="11-digit ${K}"><label class="mu" style="display:flex;gap:8px;margin-top:8px"><input type="checkbox" id="bvc"> I agree that Gidan asusu may check my ${K} with an identity provider to confirm my name. We do not keep the number.</label><div class="btn" onclick="doKyc()">Verify</div>`)};
const doKyc=async()=>{try{await api(idKind=='bvn'?'/kyc':'/kyc/nin',{body:{[idKind]:document.getElementById('bv').value,consent:document.getElementById('bvc').checked===true}});await refresh();closeSheet();go('prof');toast('Verified: higher limits and loans unlocked')}catch(e){toast(e.message)}};