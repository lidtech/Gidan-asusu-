// UI helpers: sheets (pop-ups), toasts, shared demo state and button actions.
let bal=250480.32,hide=false,locked=false,tt='gidan',rc='Tunde',lastTx=null;
let billList=[['Electricity (IBEDC)','Oct 10, 2026',5000],['Data (MTN)','Oct 8, 2026',2000]];
const today=()=>new Date().toLocaleDateString(lg==='ar'?'ar-EG':'en-US',{month:'short',day:'numeric',year:'numeric'});
const toast=m=>{const d=document.createElement('div');d.className='toast';d.textContent=localizeText(m);A.appendChild(d);setTimeout(()=>d.remove(),2200)};
const closeSheet=()=>{const o=document.getElementById('ov');if(o)o.remove()};
const sheet=(title,body)=>{closeSheet();const d=document.createElement('div');d.className='ov';d.id='ov';d.innerHTML=`<div class="sh"><div class="row sp" style="margin-bottom:8px"><h2>${title}</h2><span class="back" onclick="closeSheet()">✕</span></div>${body}</div>`;d.onclick=e=>{if(e.target==d)closeSheet()};A.appendChild(d);localizeNode(d)};
const rows=r=>r.map(x=>`<div class="row sp mu" style="padding:6px 0"><span>${esc(x[0])}</span><b style="color:var(--tx)">${esc(x[1])}</b></div>`).join('');
const act=k=>k=='login'?logout():k.startsWith('info:')?infoPage(k.slice(5)):go(k);
const infoPage=k=>({
 limits:()=>sheet('Fund Transfer Limits',rows([['Per transaction','₦1,000,000'],['Daily transfers','₦5,000,000'],['Bills & airtime daily','₦200,000']])+`<div class="btn" onclick="closeSheet();toast('Limit increase request sent')">Request increase</div>`),
 notif:()=>openInbox(),
 help:()=>sheet('Help & Support',rows([['Call','0800-000-0000 (sample)'],['Email','support@example.com (sample)'],['Hours','24/7']])+`<div class="btn" onclick="closeSheet();toast('Connecting you to support…')">Chat with us</div>`),
 about:()=>sheet('About Gidan asusu',`<p class="mu">Your Bank. Your Home.</p>`+rows([['Version','1.0 (prototype)'],['Savings','From ₦2,000 with rewards'],['Languages','English, Hausa, Yorùbá, Igbo, Pidgin, Arabic']])),
 settings:()=>sheet('Settings',`<div class="lg" onclick="closeSheet();go('lang')"><span>${glyph('lang')} ${t('lang')}</span><span>›</span></div><div class="lg" onclick="closeSheet();infoPage('notif')"><span>${glyph('bell')} Notifications</span><span>›</span></div><div class="lg" onclick="closeSheet();logout()"><span>↪ Log Out</span><span>›</span></div>`),
 fund:()=>sheet('Add money (sandbox)',`<p class="mu">Live deposits arrive by bank transfer to your account number: <b>${acct.number}</b></p><input class="in" id="fa" type="number" placeholder="₦ Test amount"><div class="btn" onclick="devFund()">Add test money</div>`),
 reset:()=>sheet('Reset password',`<input class="in" placeholder="Phone number or email"><div class="btn" onclick="closeSheet();toast('Password reset needs an email/SMS provider (not connected yet)')">Send reset code</div>`)
})[k]();
const startLive=async()=>{try{await api('/savings',{body:{name:'Livestock Plan',target:150000,icon:'farm'}});await refresh();go('save')}catch(e){toast(e.message)}};
const farmInfo=n=>({
 'Livestock Plan':()=>sheet('Livestock Plan',`<p class="mu">Save toward goats, cattle or poultry. Start from ₦2,000.</p><div class="btn" onclick="startLive()">Start plan with ₦2,000</div>`),
 'Weather & Planting':()=>sheet('Weather & Planting',`<p class="mu">Sample data for demo</p>`+rows([['Today','31°C, sunny'],['Thursday','Rain likely'],['Advice','Plant maize after two rain days']])),
 'Crop Insurance':()=>sheet('Crop Insurance',rows([['Crop Basic','₦2,500 / season'],['Livestock Cover','₦4,000 / season']])+`<div class="btn" onclick="closeSheet();toast('Quote request sent')">Get a quote</div>`),
 'Co-op Groups':()=>sheet('Co-op Groups',[['Kaduna Maize Growers',42],['Kano Pepper Co-op',28],['Sokoto Livestock Group',35]].map(g=>`<div class="card row sp"><div><b>${g[0]}</b><div class="mu">${g[1]} members</div></div><span class="pill" style="cursor:pointer" onclick="toast('Request sent to ${g[0]}')">Join</span></div>`).join(''))
})[n]();
const mq=v=>document.querySelectorAll('.pr').forEach(e=>e.style.display=e.dataset.s.includes(v.toLowerCase())?'':'none');
const rcFilter=v=>document.querySelectorAll('.rcp').forEach(e=>e.style.display=e.dataset.s.includes(v.toLowerCase())?'':'none');
let pcb=null;
const askPin=cb=>{pcb=cb;sheet('Enter transaction PIN',`<input class="in" id="pin" type="password" inputmode="numeric" maxlength="4" placeholder="4-digit PIN"><div class="btn" onclick="pinOk()">Confirm</div>`)};
const pinOk=()=>{const p=document.getElementById('pin').value;closeSheet();if(pcb)pcb(p)};
